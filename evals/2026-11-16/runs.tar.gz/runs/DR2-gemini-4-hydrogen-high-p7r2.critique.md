### Major risks
- **Silent corruption / missed edits (1-second `mtime`):** Reusing `snapshot()`'s whole-second `int(st_mtime)` + `size` misses any edit or mid-copy write that occurs within the same second without changing file size. Both change detection and the post-copy re-stat integrity check will falsely report a clean sync.
- **Corrupt manifest on crash:** Rewriting `.syncd_manifest.json` in place means a crash or power loss mid-write leaves invalid JSON. Startup fails before journal replay can repair anything, and journal replay only records copies—not deletions—if the manifest is lost.
- **Broken single-instance locking:** Releasing the lock *before* committing the manifest creates a race where a second `syncd` instance reads a stale or half-written manifest and overwrites entries. A plain PID lockfile without `flock`/`O_EXCL` and stale-PID detection also races at startup and permanently deadlocks after `SIGKILL`.
- **Non-atomic `dst` writes:** Writing directly into `dst` exposes half-written files to readers during large copies and leaves truncated files in `dst` if `syncd` crashes mid-copy.

### Wrong assumptions
- **"200 ms debounce adds at most 200 ms latency with a 500 ms poll":** You cannot observe a 200 ms quiet window with 500 ms sampling. A file only gets re-checked on the next poll (≥500 ms later), so real latency is 1–2 poll intervals (500–1000+ ms), and bursts occurring between polls aren't debounced at all.
- **"In-place manifest rewrite saves write amplification vs tmp+rename":** Rewriting the entire manifest JSON on *every* 500 ms cycle—even when nothing changed—causes constant write amplification; `os.replace` costs zero extra data writes and eliminates manifest corruption.
- **"Pending set is bounded by one poll's worth of changes":** Files that keep changing past the quiet period, hit transient errors, or vanish mid-copy stay in `pending` across polls unless explicitly evicted (e.g., on `ENOENT`).
- **"`mtime` is guaranteed to change on every edit":** False for `git checkout`, `tar`/`cp -p`, `mmap` writes, or same-second in-place updates.

### What will break under real load
- **Idle and burst I/O collapse at 50k files:** Serializing and rewriting a 50,000-entry JSON manifest (~5–10 MB) every 500 ms burns ~10–20 MB/s continuously even when idle. Cold-cache `os.walk` + 50k `stat()` calls frequently exceed 100 ms (especially on macOS/APFS, VMs, or busy build disks), causing poll drift.
- **Build bursts stall the daemon:** Synchronous file copies inside the poll loop block scanning, delaying detection of deletions and new writes for seconds during a multi-hundred-file compile.
- **Unbounded journal growth:** Appending every copy to `.syncd_journal.log` without compaction/truncation makes the journal grow indefinitely and slows every restart.

### Decisions to change first
1. **Use atomic writes everywhere:** Write both `dst` files (via staging temp file + `os.replace`) and the manifest (`tmp` + `fsync` + `os.replace`), and **skip manifest commits on idle cycles** (only commit when state actually changed).
2. **Keep the lock across the entire lifecycle:** Hold an advisory OS lock (`fcntl.flock`) for the lifetime of the daemon process—never release it before manifest commit.
3. **Fix change detection precision:** Track `st_mtime_ns` (and `st_ino` / `st_ctime_ns`) internally for diffing and post-copy verification; convert to whole-second `mtime` only if/when exporting for `synccli` compatibility.
4. **Add journal compaction & deletion entries:** Record deletes in the journal too, and truncate/rotate the journal immediately after each clean atomic manifest commit.
5. **Fix the poll/debounce timing & error paths:** Either make the poll interval smaller than the debounce (or use OS watchers with periodic fallback rescan), evict `ENOENT` files from `pending` as deletions, and decouple scanning from copying (or bound copies per tick).
