I've read both docs plus the code they govern. Here is the execution plan. **No modifications were made** — text only.

---

# Execution Plan — `synccli` JSON output mode + dry-run UX

## Context (facts the plan rests on)

| Fact | Source | Consequence |
|---|---|---|
| `sync(src_root, dst_root, dry_run=False)` returns a `list[str]` of copied relpaths | `synccli.py:72` | "stable signature" must mean **params *and* return type** stay unchanged |
| `sync()` already returns the would-be-copied list under `dry_run=True` and returns *before* writing the manifest | `synccli.py:81-82` | GOAL item 2 is nearly free — it must not be "fixed" |
| `main()` is the only stdout writer; it prints one relpath per line | `synccli.py:97-98` | Human mode is trivially preserved by branching in `main()` |
| `main()` always returns 0; exceptions escape to stderr | `synccli.py:99` | "Exit code unchanged" ⇒ JSON mode also returns 0; no special error protocol |
| `incremental.py:5` imports `copy_file` only (return value ignored) | `incremental.py` | `copy_file` may be made to return a bool without breaking it — but it is **not** in the JSON path |
| `incremental.py` is **not** imported by `synccli.py` | grep | Dead-until-wired module; out of scope |
| DESIGN.md:31 — the future `syncd` daemon "reuses `sync()` directly" | `DESIGN.md:31` | Hard reason to keep `sync()` a list-returning wrapper |
| Baseline: 6 unittest tests, Python 3.10.11, stdlib-only | `test_synccli.py`, `python3 --version` | Test-count deltas are measurable; no dep additions permitted |
| `copy_file` swallows `OSError` silently | `synccli.py:66-69` | `copied` can over-report; drives decision **D2** |

## Open decisions — must be settled at Task 1 (design-review) before code

- **D1 — What is `skipped`?** GOAL names the key but not its meaning.
  - *Proposed:* `skipped = len(source files) - len(copied)` — files not copied this run (already up-to-date **and** failed copies). Symmetric with dry-run (`copied` = would copy, `skipped` = would not). Derivable from `build_manifest()`'s result, no new error machinery.
  - *Alternative:* `skipped` = count of **failed** copies only. Then the key is always `0` in dry-run and requires `copy_file` to report success/failure (a `copy_file` return-type change — safe for `incremental.py`, but a wider diff).
  - *Impact if wrong:* one counter expression inside the new result object — cheap to flip. Flagging it because it is the only real spec gap.
- **D2 — Failure accounting:** are failed copies counted separately from `skipped`? GOAL's shape has exactly 4 keys, so no `errors` key may be added without deviating. *Proposed:* fold failures into `skipped`; stderr-only diagnostics if any (stdout must stay pure).
- **D3 — `src`/`dst` values:** verbatim command-line strings (*proposed*) vs. `os.path.abspath`. Verbatim is the least surprising and trivially testable.
- **D4 — Error path in JSON mode:** GOAL says exit code unchanged ⇒ an exception still propagates (traceback → **stderr**, stdout stays empty, exit ≠ 0). *Proposed:* no JSON error object, to keep "exit code unchanged" literal.

---

## Task 0 — Recon: lock the contract surface
- **Objective:** enumerate every internal caller of `sync()` / `copy_file` and every stdout writer, so the "signature stable" constraint is enforced against facts, not assumptions; establish the pre-change human-mode output as a golden fixture for later byte-comparison.
- **Files:** none (read-only). Reference: `synccli.py`, `test_synccli.py`, `incremental.py`, `DESIGN.md:31`.
- **Pipeline agent:** `explore`
- **Risks:** an unseen/external caller of `sync()` (the planned `syncd`) breaks if the return type drifts to an object — hence the wrapper design in Task 2; a second stdout writer discovered late would contaminate JSON output.
- **Acceptance criterion:** report lists every call site as `file:line`, explicitly states the post-change required contract of `sync()` (same params, still returns `list[str]`), confirms "no other stdout writes than `synccli.py:97-98`", and records the baseline test count (6) plus a golden expected human-mode stdout for a known fixture.

## Task 1 — Contract review (design-review)
- **Objective:** settle D1–D4 and emit the exact JSON payload contract the implementer must code literally: key set, value types, list ordering, `src`/`dst` form, `skipped` formula, dry-run semantics, failure accounting, error path.
- **Files:** none — the decision is recorded in the agent's report, **not** a new doc file (GOAL does not request one; per "ask before acting").
- **Pipeline agent:** `cheap-design-review`
- **Risks:** picking the wrong `skipped` semantics bakes a wrong machine-readable contract; inventing a 5th key breaks the specified shape; scope creep into `incremental.py`/`DESIGN.md`.
- **Acceptance criterion:** a written contract naming, for each of the 4 keys, its exact value for the three scenarios (fresh copy, no-op re-sync, dry-run) — plus an explicit ruling on D1–D4 — that Task 2/3 can implement without further interpretation.

## Task 2 — Implementation
- **Objective:** add `--json`; restructure so a richer internal result is available while `sync()` stays a stable list-returning wrapper; keep human mode byte-identical.
- **Files:** modify `synccli.py` only.
  - Introduce an internal result carrier (copied list, skipped count, and — only if D2 demands it — a failures list). Keep it stdlib-only (`dataclasses` allowed; no new deps).
  - `sync(src_root, dst_root, dry_run=False)` becomes a thin wrapper returning `result.copied` (still a `list[str]`); the copy/manifest logic stays in one place — **no** duplicate manifest scan from `main()`.
  - `parser.add_argument("--json", action="store_true")` next to `--dry-run` (`synccli.py:94`).
  - `main()`: if `args.json` → emit exactly one `json.dumps(payload)` document to stdout and return 0; else keep the existing per-line loop untouched (`synccli.py:97-98`). No other `print`.
- **Pipeline agent:** `cheap-code`
- **Risks:** return-type drift breaking `sync()` callers (mitigated by wrapper + reviewer check); a second manifest scan (perf) if stats are recomputed in `main()`; stdout contamination from an error path (traceback goes to stderr — acceptable, per D4); breaking dry-run's "do not write the manifest" behavior (`synccli.py:81-82` must stay as-is); manifest written on dry-run would be a silent behavioral regression.
- **Acceptance criterion:** `python3 -c "import inspect,synccli; print(inspect.signature(synccli.sync))"` prints `(src_root, dst_root, dry_run=False)`; `synccli.sync(src,dst)` still returns a `list` of `str`; `python3 -m synccli --json src dst` stdout parses as **one** JSON document whose key set is exactly `{copied, skipped, src, dst}`; `python3 -m synccli src dst` stdout is byte-identical to the Task 0 golden fixture; only stdlib imports present (`argparse, json, os, sys, dataclasses`).

## Task 3 — Tests
- **Objective:** unit tests for the JSON shape and dry-run semantics, added to the existing file as GOAL item 4 requires.
- **Files:** modify `test_synccli.py` (extend; keep existing style — `tempfile.mkdtemp`, `unittest`).
  - `test_json_stdout_is_single_valid_json_object` — capture stdout (`contextlib.redirect_stdout` + `io.StringIO`), `json.loads` succeeds, and the raw decoder consumes the *entire* stdout (proves no second document / no stray text).
  - `test_json_keys_and_types` — key set exactly `{copied, skipped, src, dst}`; `copied` is `list[str]`, `skipped` is `int`, `src`/`dst` equal the argv values (D3).
  - `test_json_copied_matches_actual_copies` — payload `copied` == the files present in `dst`.
  - `test_json_dry_run_lists_would_copy` — with `--dry-run --json`: `copied` lists the pending file, `dst` contains **no** copied file **and no** `.sync_manifest.json`.
  - `test_json_dry_run_skipped_semantics` — pre-synced file + 1 new file ⇒ `skipped == 1`, `copied == [new]` (per D1).
  - `test_human_mode_unchanged` — non-JSON run prints one relpath per line, no braces, exit 0.
  - `test_json_and_human_agree` — same fixture ⇒ JSON `copied` set == human stdout lines.
- **Pipeline agent:** `cheap-code` — **continue Task 2's session** (same feature, same files, its context is directly useful).
- **Risks:** over-specifying `skipped` makes the test brittle if D1 differs from the proposal (mitigated by Task 1); capturing stdout incorrectly (must patch `sys.stdout`, not the `print` call); fixture cleanup conventions (existing tests don't clean temp dirs — match the existing style rather than refactoring).
- **Acceptance criterion:** `python3 -m unittest -v` → all tests pass, ≥ 6 new tests present, and the 6 pre-existing tests still pass unchanged (zero regressions, zero errors).

## Task 4 — Review
- **Objective:** verify the diff against every line of GOAL.md and every stated constraint, from a fresh perspective.
- **Files:** none (read-only) — reviews the diff of `synccli.py` + `test_synccli.py`.
- **Pipeline agent:** `cheap-review`
- **Risks:** reviewer waving through a wrong `skipped` semantic (brief must carry the D1 ruling); scope creep into `incremental.py`/`DESIGN.md`/`README.md` (must be absent from the diff).
- **Acceptance criterion:** explicit verdict PASS, or findings each classified **minor**/**major** with `file:line`; explicit per-item confirmation of: single JSON object on stdout and nothing else; exact 4 keys; dry-run semantics (copied = would-copy, dst untouched); human mode unchanged; exit code unchanged; no new dependencies; Python 3.10 stdlib only; `sync()` signature **and** return type stable; tests present and passing.

## Task 5 — End-to-end verification
- **Objective:** prove the acceptance criteria against the real CLI binary path, not just in-process unit calls.
- **Files:** none.
- **Pipeline agent:** `cheap-mech`
- **Risks:** stale `__pycache__` (repo tracks `__pycache__/*.pyc` — do **not** commit changes to them); running from the wrong cwd; JSON piped through a pager/quoting artifact in the check commands.
- **Acceptance criterion:** a recorded pass/fail for each of: `--help` still works; human mode golden output matches Task 0; `--json` stdout is exactly one JSON doc (`python3 -m synccli --json s d | python3 -c "import json,sys; d=json.load(sys.stdin); assert set(d)=={'copied','skipped','src','dst'}"` → exit 0); `--json --dry-run` leaves `dst` empty; `--json` exit code is 0; `python3 -m unittest -v` fully green.

## Task 6 — Optional: README usage note — **BLOCKED pending explicit approval**
- **Objective:** document the new flag (e.g. a `--json` bullet under the usage lines in `README.md`).
- **Files:** `README.md` (one line).
- **Pipeline agent:** `cheap-mech` — only if you approve.
- **Risks:** an unrequested file change; none technically.
- **Acceptance criterion:** `README.md` mentions `--json`; `git diff --name-only` then lists `README.md` in addition to the two implementation files.

---

## Sequence & gating

`T0 (explore) → T1 (design-review) → T2 (impl) → T3 (tests, same session as T2) → T4 (review) → T5 (verify)`
- **T1 gates T2/T3**: the `skipped` formula must be fixed before a single line is written, or the JSON contract is guesswork.
- **T4 findings**: minor → resume the Task 2/3 `cheap-code` session (same feature, context useful); major → escalate to `strong-code`.
- **T6 is blocked** until you say yes.

## Explicitly out of scope (no changes)
`DESIGN.md` (v2 daemon design), `incremental.py` (mutable-default-arg bug in `filter_excluded`, unused `EXCLUDE_TOP_DIRS` entry, dead `copy_many`/`merge_manifest` — observed, not touched), `GOAL.md`, and the tracked `__pycache__/*.pyc` artifacts.

## Verification checklist (consolidated)
1. `python3 -m unittest -v` → all green, ≥ 6 new tests, 6 legacy tests intact.
2. `inspect.signature(synccli.sync)` == `(src_root, dst_root, dry_run=False)`; return type still `list[str]`.
3. `python3 -m synccli --json SRC DST` → stdout = exactly one JSON doc, keys exactly `{copied, skipped, src, dst}`; exit 0.
4. `python3 -m synccli --json --dry-run SRC DST` → `copied` = would-copy; `dst` has no file and no `.sync_manifest.json`.
5. `python3 -m synccli SRC DST` → byte-identical to the pre-change golden output.
6. `git diff --stat` → only `synccli.py` + `test_synccli.py` (+ `README.md` iff Task 6 approved); imports remain stdlib-only.

**Awaiting your call on D1 (`skipped` semantics) and on Task 6 before dispatching Task 1.**
