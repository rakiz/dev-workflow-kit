Read both (plus `DESIGN.md`, `incremental.py`, baseline test run). Scope is **only** items 1–4 of `GOAL.md`: `--json` + `--dry-run` interplay + unchanged human mode + tests. `DESIGN.md` (v2 daemon) is unrelated and out of scope.

**Baseline fact (measured, not assumed):** `python3 -m unittest -v` is already **red** — `test_first_item_stale_is_included` fails because `collect_stale` starts at `range(1, ...)` (synccli.py:55). This is pre-existing and outside GOAL; acceptance must be “no new failures vs baseline”, not “suite green”.

---

### T1 — Exploration: freeze the current contract and IO surface
- **Objective:** Inventory every stdout writer, every `sync()` caller, and the exact current CLI behavior so the JSON branch cannot accidentally add stdout noise or break internal callers.
- **Files:** read-only — `synccli.py`, `test_synccli.py`, `incremental.py`, `README.md`, `GOAL.md`.
- **Agent:** `explore`.
- **Risks:** Missing a print/log path (e.g. a future/again-added `print`), or an external `sync()` caller whose signature the change might tempt to alter.
- **Acceptance criteria:** Report enumerates: (a) all `print`/`sys.stdout`/`logging` sites; (b) all `sync(` call sites; (c) confirmation that `copy_file` swallows `OSError` silently (synccli.py:65-69); (d) exact current stdout for human and `--dry-run` modes, with the command used to observe it. Zero files modified.

### T2 — Design review: settle `skipped` semantics and the stdout purity rule
- **Objective:** `GOAL.md` fixes the JSON keys but not the meaning of `"skipped": N`. Decide and record one definition before code: (a) unchanged source files = `len(scan_files(src)) - len(copied)`, (b) copy failures swallowed by `copy_file`, or (c) excluded/ignored entries. Also fix the rule “single JSON object on stdout, exit code unchanged (0)” and how invalid args behave.
- **Files:** no code changes; decision recorded in the task output (goes into the PR description / impl brief).
- **Agent:** `design-review` (with `cheap-design` draft if a written option comparison is wanted).
- **Risks:** Picking (b) requires changing `copy_file` error reporting, which could affect `incremental.py`; picking (a) requires an extra `scan_files()` call (cheap, pure). Ambiguity left unresolved ⇒ tests assert the wrong thing.
- **Acceptance criteria:** One explicit sentence defining `skipped`, plus the chosen exit-code and stdout rules, and a note on whether `sync()` stays untouched (it must — signature stable). Reviewer verdict recorded; no file modified.

### T3 — Implementation: add `--json` (and dry-run interplay) without touching `sync()`
- **Objective:** Add `--json` to the argparse parser; in JSON mode emit exactly one `json.dumps(...)` object `{"copied": [...], "skipped": N, "src": args.src, "dst": args.dst}` to stdout and nothing else; in human mode keep `print(rel)` per path. `copied` comes from the existing `sync(..., dry_run=args.dry_run)` return value, so dry-run semantics are inherited, not re-implemented. Keep `sync()` byte-for-byte unchanged.
- **Files:** modify `synccli.py` only (`main()`, synccli.py:90-99; no new imports — `json` already imported at line 3).
- **Agent:** `impl` (`cheap-code`).
- **Risks:** `skipped` computed by re-scanning vs. inference mismatch; accidental second stdout write; JSON non-serializability (all values here are strings/ints, so low); changing `sync()` despite the constraint; Python 3.10-only syntax violations (none needed).
- **Acceptance criteria:** `python3 -m synccli SRC DST --json` prints exactly one line that `json.loads` accepts, with exactly the four keys and correct types (`list`, `int`, `str`, `str`); `--json --dry-run` prints the same shape and copies nothing and leaves the dst manifest absent/unchanged; human mode output is unchanged (path per line); `sync()` definition unchanged (verified by diff); exit code 0 in all success cases.

### T4 — Implementation: add JSON-shape tests to `test_synccli.py`
- **Objective:** Add a `TestMainJson` (or equivalent) class covering: valid JSON, keys present with correct types, dry-run semantics (`copied` lists would-be copies, no files written, manifest untouched), human mode still path-per-line, and stdout purity (parse captured stdout as a single JSON document, assert no trailing text).
- **Files:** modify `test_synccli.py` only (append new test class; reuse `tempfile` pattern from existing `setUp`).
- **Agent:** `impl` (`cheap-code`), tests reviewed by `review`.
- **Risks:** Capturing stdout with `contextlib.redirect_stdout` and forgetting `stderr`; asserting against the pre-existing `collect_stale` failure; over-coupling tests to the chosen `skipped` number instead of deriving it; tests that pass with `--dry-run` but do not actually assert no bytes written.
- **Acceptance criteria:** New tests pass; JSON test asserts `set(obj) == {"copied","skipped","src","dst"}` and `isinstance` for each; dry-run test asserts the target file is absent and `.sync_manifest.json` was not created; human-mode test asserts exact `"rel\n"` output; the only failing test in the suite remains the pre-existing `test_first_item_stale_is_included`.

### T5 — Review: independent read-only review of the combined diff
- **Objective:** Check the diff against all four GOAL items and both constraints, including stdout purity and the `sync()` signature freeze; classify findings minor/major.
- **Files:** read-only — `synccli.py`, `test_synccli.py`; may read `GOAL.md`, `incremental.py`.
- **Agent:** `review` (`cheap-review`, fresh instance, briefed with T1–T4 outputs).
- **Risks:** Reviewer “fixes” the unrelated `collect_stale` bug unasked; missing an added stdout write; accepting a test that asserts implementation details rather than the contract.
- **Acceptance criteria:** Verdict lists each GOAL requirement with pass/fail and file:line evidence; any finding classified minor (back to `impl` via resumed instance) or major (escalate to `strong-code`); explicit confirmation that `sync()` signature is unchanged and `incremental.py`/`DESIGN.md` were not modified.

### T6 — Verification gate: run the acceptance commands on the final tree
- **Objective:** Execute the literal acceptance checks end-to-end on a scratch `src`/`dst` pair, comparing test results to the recorded baseline.
- **Files:** no source edits; scratch dirs only (outside the repo).
- **Agent:** `review` (read-only verification; `explore` only if a discrepancy needs tracing).
- **Risks:** Green-washing while the pre-existing failure persists; shell redirection merging stderr into stdout and hiding purity violations; leaving scratch files in the repo.
- **Acceptance criteria (all must hold):**
  1. `python3 -m unittest -v` fails **only** on the pre-existing `test_first_item_stale_is_included`.
  2. `python3 -m synccli SRC DST --json 2>/dev/null | python3 -m json.tool` succeeds (single object, four keys).
  3. `python3 -m synccli SRC DST --json --dry-run` exits 0, copies nothing, leaves `dst` and manifest untouched.
  4. `python3 -m synccli SRC DST` emits only relative paths, one per line (diff vs baseline output).
  5. `git status --porcelain` shows only `synccli.py` and `test_synccli.py` modified; `.git`-tracked `DESIGN.md`/`incremental.py` untouched.

---

**Out-of-scope items (no action unless you approve):** (i) the pre-existing `collect_stale` off-by-one at synccli.py:55 and its failing test; (ii) `filter_excluded`’s mutable default `excluded=[]` in incremental.py:10; (iii) any `DESIGN.md` daemon work. **Ask-before-acting:** say the word if you want any of these folded into a follow-up task.

No files were modified.
