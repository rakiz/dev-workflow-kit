**Verdict:** Polling over watchers is defensible here. But several guarantees in DESIGN.md are false as written, and the timestamp model underneath them is wrong. Fix those before writing code.

**Major risks**

1. **Same-second blind spot (L58, L72).** The manifest uses whole-second mtime plus size. Two edits in the same second with the same size are invisible to the diff, and the post-copy re-stat (L25-27) can't catch them either. "mtime is guaranteed to change on every edit" is also false: `cp -p`, `rsync -t`, and `tar -x` preserve or set older mtimes.

2. **Latency bound is false (L16-20).** The debounce restarts on every change, so a continuously written file never goes quiet and is never copied. Latency is unbounded, not "one poll + 200 ms". The 200 ms quiet period also can't be measured: changes are seen only at 500 ms polls, and mtime has 1 s resolution.

3. **Integrity claim is false (L25-28).** Copying in place means readers see partial files, and a crash mid-copy leaves a truncated file in dst. The rejection of tmp+rename (L60-61) is backwards: a rename adds no write amplification beyond the copy itself.

4. **Single-instance guarantee is false (L41-48).** The lock exists only during a poll cycle, so a second daemon can start in the gap. Two processes rewriting the manifest in place will lose updates or tear the file. "Entries merge cleanly" has no merge logic specified, and a last-writer-wins rewrite drops the other process's entries. `synccli` also writes the same dst and manifest and is not covered by any daemon lock.

5. **Mass-deletion hazard (L38-40).** Reconcile deletes anything absent from src. If src is an unmounted volume, a moved directory, or an `os.walk` that silently skips a subtree on a permission error, the next poll wipes the mirror. Build tools that regenerate outputs make this more likely.

6. **Repair path is undefined (L29-34).** "Journal replay repairs a torn manifest" holds only if the journal is never truncated before the manifest is durable. The doc never says when the journal is compacted, so it also grows without bound on a long-running daemon.

7. **Scan cost is asserted, not measured (L12-15).** "Well under 100 ms" for 50k stats is optimistic on macOS with Python `os.walk`, especially with Spotlight or endpoint-security tools running. Warm runs of 150-400 ms are plausible, and worse under build load or a cold cache. At a 500 ms interval, a 300 ms scan keeps a core about 60% busy at idle, and nothing stops the loop from falling behind. Scan and copy also share one thread, so one burst of large files delays detection.

8. **Backpressure claim is wrong (L21-24).** The pending set is bounded by the number of changed files, not by "one poll's worth". Memory isn't the constraint; latency is. A 500-file burst of large copies blocks the scan for its full duration.

**Unhandled cases**

- No exclude list: `.git`, `node_modules`, build output, `.DS_Store`, and editor temp files. Atomic-save editors create create/delete churn on every save.
- Case-insensitive APFS (the macOS default): a case-only rename can make the delete of the old name remove the file just copied under the new one if deletes run after copies in the same cycle.
- Rename as delete+create means a rename of a large file or directory triggers a full recopy. On macOS, `clonefile` makes this cheap, and the choice should be made now.
- No plan for the first full sync of 50k files, including throughput and resumability.

**Change first, in order**

1. **Timestamp model.** Store `st_mtime_ns`, `st_size`, `st_ino`, and `st_ctime_ns`; compare with `!=`, not `>`. Version the manifest rather than reusing synccli's format. Everything else depends on this.
2. **Process-lifetime `flock`** held by syncd and synccli alike. Drop the per-cycle lock and the commit-without-lock idea.
3. **Deletion guard.** Abort reconcile when the src root is missing or the walk reports errors. Cap deletions per pass, or require confirmation above a threshold.
4. **Atomic writes.** Copy to a temp file in dst and rename. Write the manifest via tmp+rename. Truncate the journal only after the rename succeeds, and specify fsync points.
5. **Rewrite the latency section.** Add a max-age cap that forces a copy during continuous writes, state the real bound (poll + scan + debounce + copy time), and track lag (source change to dst commit) rather than pending count.
6. **Measure before committing to 500 ms.** Benchmark the scan on the target machine, warm and cold, during a build. Use `sleep = max(0, POLL - scan_time)` and run copies in a worker pool separate from the scan.
