# Execution plan

**No files have been modified.**

## 1. Inspect current CLI, synchronization flow, and tests

- **Objective:** Identify where arguments are parsed, how `--dry-run` currently affects copy reporting, where `sync()` returns its results, and where stdout is written. Establish existing test conventions and baseline behavior.
- **Files to create/modify:** None. Read-only inspection of `synccli.py`, `test_synccli.py`, and any directly relevant modules discovered during exploration.
- **Pipeline agent:** `explore`
- **Risks:**
  - Internal callers depend on the existing `sync()` signature.
  - Copy reporting may currently occur inside `sync()`, making JSON formatting intrusive if handled there.
  - Existing stdout output or tests may encode behavior that must remain unchanged outside JSON mode.
- **Verifiable acceptance criterion:** Produce a concise implementation brief identifying the exact functions and tests involved, current dry-run/copy semantics, a safe output-formatting boundary, and the baseline result of `python3 -m unittest -v`.

## 2. Review and approve the output contract and implementation approach

- **Objective:** Confirm a minimal design before implementation:
  - Add `--json` without changing `sync()`’s signature.
  - Emit exactly one object via the Python standard library, with keys `copied`, `skipped`, `src`, and `dst`.
  - Keep stdout free of all other output in JSON mode.
  - With `--json --dry-run`, populate `copied` with paths that would be copied.
  - Preserve current exit codes and human-mode output.
  - Use no new dependencies and remain Python 3.10-compatible.
- **Files to create/modify:** None; produce an approved implementation/design brief.
- **Pipeline agent:** `design-review`
- **Risks:**
  - Accidentally changing the return contract or signature of `sync()`.
  - Ambiguous dry-run semantics or inconsistent result ordering.
  - Diagnostic output leaking into stdout and invalidating machine-readable output.
- **Verifiable acceptance criterion:** The design explicitly specifies where JSON serialization occurs, how both normal and dry-run results reach it, and how human output and exit behavior remain unchanged. Any unresolved contract questions must be settled before coding.

## 3. Implement JSON mode and add focused unit tests

- **Objective:** Implement the approved CLI changes and tests with minimal intrusion.
- **Files to create/modify:**
  - `synccli.py` — add the CLI flag and JSON-specific rendering while preserving `sync()`’s signature.
  - `test_synccli.py` — add unit coverage for JSON validity, required keys, normal output, and combined JSON/dry-run behavior.
  - No new files or dependencies expected.
- **Pipeline agent:** `impl`
- **Risks:**
  - JSON mode printing human-readable paths or other text to stdout.
  - Dry-run reporting actual copies rather than prospective copies.
  - Regressions in human output, skipped counts, source/destination values, or exit codes.
  - Tests merely checking subprocess text rather than parsing and asserting JSON semantics.
- **Verifiable acceptance criterion:**
  - `python3 -m unittest -v` passes.
  - Tests parse stdout with `json.loads` and assert one object containing exactly the required keys and expected value types.
  - Tests confirm that normal JSON mode reports copied files and that `--json --dry-run` reports files that would be copied without copying them.
  - Existing human-mode tests still pass, with one path per line.
  - `sync()` retains its existing signature and no dependency declarations change.

## 4. Independently review and verify the completed change

- **Objective:** Audit the implementation against `GOAL.md`, inspect the complete diff, and rerun the relevant tests.
- **Files to create/modify:** None during the review itself. Any confirmed defects return to `impl` for correction, followed by another review.
- **Pipeline agent:** `review`
- **Risks:**
  - Tests missing stdout contamination, exit-code preservation, or dry-run filesystem behavior.
  - Unnecessary changes to unrelated synchronization logic.
  - JSON serialization appearing correct while output includes multiple lines/objects or other text.
- **Verifiable acceptance criterion:** The reviewer confirms all goal requirements, Python 3.10 stdlib-only compatibility, unchanged human behavior and `sync()` signature, and reports a clean `python3 -m unittest -v` run. No known correctness issues or unverified acceptance criteria remain.
