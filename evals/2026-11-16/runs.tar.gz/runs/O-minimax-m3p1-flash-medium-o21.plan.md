Read both files plus the code they describe. Here's the grounded execution plan (no modifications made).

## Repo facts the plan rests on

- `synccli.py:72` — `sync(src_root, dst_root, dry_run=False)` returns a **list** of copied relative paths; `dry_run=True` returns `to_copy` without copying or writing the manifest (dry-run semantics already correct for the goal).
- `synccli.py:90` — `main()` prints one relative path per line to stdout, returns 0.
- `synccli.py:62` — `copy_file()` **swallows `OSError`**, so `copied` can contain files that were never actually copied (and the manifest still records them → silently skipped next run). This directly affects JSON-mode accuracy.
- `incremental.py:5` — imports `copy_file` from `synccli`; `DESIGN.md:31` plans a daemon reusing `sync()` directly. → "internal callers exist" is confirmed; `sync()`'s signature/return type must not change.
- No `requirements.txt`/`pyproject.toml`; tests run via `python3 -m unittest -v`; stdlib-only.

## Tasks

**T0 — Baseline & impact map** · agent: **explore**
- Objective: confirm current stdout/exit-code behavior, capture the exact pre-change baseline (human mode output, `--dry-run` output, exit code), and enumerate every caller/consumer of `sync()`/`main()` so a stable-signature claim is evidence-based, not assumed.
- Files: none modified (read-only).
- Risks: none (read-only). Risk if skipped: a hidden internal caller is broken by T3.
- Acceptance: a written baseline listing current stdout for (a) plain sync, (b) `--dry-run`, plus the full list of `sync()`/`main()` call sites (incl. `incremental.py`, and any `syncd` scaffolding), and `python3 -m unittest -v` green before any change.

**T1 — Design decision record** · agent: **design** (cheap-design)
- Objective: resolve the two ambiguities in GOAL.md and fix the public surface, writing a short design note.
  - **`skipped` semantics** — GOAL says `"skipped": N` without defining it. Candidate: (a) source files considered but not copied (i.e. unchanged), (b) files whose copy failed, (c) excluded paths. Recommendation to evaluate: **(a)**, with failed copies reported separately if possible.
  - **How to obtain `skipped` without changing `sync()`** — options: (i) `sync()` returns a result object → **rejected, breaks the stated constraint**; (ii) add a new sibling function (e.g. `sync_detailed(src, dst, dry_run=False) -> SyncResult`) returning copied/skipped/src/dst, with `sync()` kept as a thin wrapper delegating to it → **recommended**; (iii) recompute in `main()` by re-scanning the source → **rejected** (double scan, TOCTOU drift between the two counts).
  - **Whether `copied` should exclude failed copies** — decide whether T3 must also fix `copy_file`'s swallowed-`OSError` behavior, or whether JSON mode reports copy *attempts* and documents it. Flag: fixing it changes the manifest semantics for the future daemon.
  - **`src`/`dst` values** — as-given CLI arguments (verbatim strings, not resolved/absolutized). Confirm and document.
  - **JSON formatting** — single line via `json.dumps(obj)` (one object, parseable by `json.loads(stdout)`); no other stdout writes in JSON mode (argparse `--help`/errors go to stdout/stderr only outside JSON mode).
- Files: create `DESIGN-json-mode.md` (new file; no existing source modified yet).
- Risks: choosing (i) violates the stability constraint; choosing (iii) produces counts that disagree between dry-run and real runs; an undecided `skipped` definition makes the tests meaningless.
- Acceptance: the note states one unambiguous `skipped` definition, the chosen API (name, signature, return shape) with `sync()`'s existing signature+return type **byte-identical**, the `copied`-on-failure policy, the `src`/`dst` value policy, and the stdout-purity rule; a reviewer can implement from it without asking a question.

**T2 — Design review** · agent: **design-review** (cheap-design-review)
- Objective: critique T1 before code exists; verify the "keep `sync()` stable" claim against T0's call-site list and check the JSON contract against GOAL.md line by line.
- Files: read-only (`DESIGN-json-mode.md`, `GOAL.md`, T0's baseline).
- Risks: review after impl is too late to change the public surface cheaply; skipping it risks a shipped contract change.
- Acceptance: explicit verdict (approve / approve-with-changes / reject) on: contract vs GOAL.md items 1–4, `sync()` compatibility vs the T0 caller list, determinism of `skipped` across dry-run and non-dry-run, and stdout purity. Any "approve-with-changes" item is folded into T3's brief.

**T3 — Implementation** · agent: **impl** (cheap-code)
- Objective: implement the approved contract in `synccli.py`.
- Files: modify `synccli.py` (add `--json` flag to the parser; add the detailed-result function and keep `sync()` as a delegating wrapper with its current signature and list return; add JSON emission in `main()`; ensure the JSON branch writes **exactly one** JSON object to stdout and the human branch keeps one path per line). Modify `README.md`/`GOAL.md` only if T1's note says the flag must be documented (README currently documents usage only).
- Risks: accidental stdout writes in JSON mode (e.g. `copy_file` diagnostics — currently none, but any `print` added for errors must go to **stderr**); breaking `sync()`'s list return (existing tests at `test_synccli.py:43,50` assert a list); `skipped` computed differently in dry-run vs real mode.
- Acceptance: `sync()` still returns `["a.txt"]` / `[]` per the existing tests, unchanged signature; `--json` on a 2-file src prints exactly one line that `json.loads` parses to a dict with exactly the keys `copied`, `skipped`, `src`, `dst` (types: list, int, str, str); `--json --dry-run` reports the same `copied` list as a real sync but leaves the destination untouched (no file copied, no manifest written); plain mode output is byte-identical to the T0 baseline; `python3 -m unittest -v` still green.

**T4 — Tests** · agent: **impl** (cheap-code or cheap-mech)
- Objective: add the required unit tests to `test_synccli.py` (GOAL item 4).
- Files: modify `test_synccli.py` only. Cover: valid JSON parse of stdout; all four keys present with correct types; `copied` contents match the copied files; `skipped` equals the defined value (unchanged files) and matches T1's definition exactly; dry-run semantics (JSON `copied` lists what *would* be copied; destination unchanged, no manifest written); **stdout purity** in JSON mode (nothing but the single JSON object) — assert via `contextlib.redirect_stdout` for the shape and, if cheap, one `subprocess` run of `python3 -m synccli --json` to prove end-to-end stdout purity and exit code 0; human mode unchanged (one path per line).
- Risks: tests asserting an undefined `skipped` value → false failure or, worse, a test written to match buggy behavior; brittle assertions on exact key ordering or whitespace (parse the JSON, don't string-match); tests that leave temp dirs behind.
- Acceptance: new tests fail against the pre-change code for the right reason (feature absent) and pass after T3; the suite asserts JSON shape, key presence, dry-run semantics, stdout purity, and exit code 0; `python3 -m unittest -v` fully green with no changes to the existing three test classes' expectations.

**T5 — Review** · agent: **review** (cheap-review, different model lineage)
- Objective: read-only review of the T3+T4 diff against GOAL.md and T1's contract.
- Files: read-only (`synccli.py`, `test_synccli.py`, `DESIGN-json-mode.md`, `GOAL.md`).
- Risks: a cheap review may miss a stdout-purity leak or an off-by-one in `skipped`; findings after the fact cost a rework round.
- Acceptance: findings classified **minor** (→ T6) or **major** (→ escalate per AGENTS.md). Explicitly checked and stated: `sync()` signature/return compatibility, no new imports outside the stdlib, Python 3.10 compatibility (no 3.11+ syntax), single-object stdout in JSON mode, no stray stdout prints, dry-run writes nothing to `dst`, human mode byte-identical.

**T6 — Fix round** · agent: **impl** (cheap-code, resumed with T3/T4's task_id)
- Objective: address minor findings from T5 only; no scope expansion.
- Files: same as T3/T4.
- Risks: fixing more than the findings; a "fix" that changes the public contract without re-running T2's checks.
- Acceptance: each minor finding has a corresponding change or an explicit written rationale for not changing it; `python3 -m unittest -v` green; no change to `sync()`'s signature or return type.

**T7 — Final audit** · agent: **strong-review** (strongest rung)
- Objective: independent final verification of the delivered feature against GOAL.md items 1–4 and the four constraints.
- Files: read-only.
- Risks: none of its own; it is the last gate.
- Acceptance: a verdict per GOAL item (1 single JSON object with nothing else on stdout; 2 dry-run semantics; 3 human mode unchanged; 4 unit tests added) and per constraint (no new deps, stdlib-only, Python 3.10, `sync()` stable), each backed by the actual test command output; a clean run of `python3 -m unittest -v`; and a manual end-to-end run of `python3 -m synccli --json src dst` and `python3 -m synccli --json --dry-run src dst` with quoted stdout.

## Notes for you before execution

- **The one real ambiguity is `skipped`.** GOAL.md never defines it; T1 must resolve it or T4's tests are meaningless. My recommendation: `skipped` = source files considered but not copied (unchanged), with failed copies surfaced separately — but that may exceed the contract's four keys, so T1 should decide.
- **Pre-existing bug surfaced by this work:** `copy_file` swallows `OSError` (`synccli.py:62-69`), so `copied` can over-report and the manifest can record files that were never written. I have **not** proposed fixing it as part of this goal, since it changes manifest semantics the planned `syncd` daemon will depend on — flagging it for your decision rather than acting on it.
- **Also left untouched (out of scope, needs your yes):** `incremental.py:10` `filter_excluded` has a mutable default argument (`excluded=[]`) that leaks across calls, and `incremental.py` is currently unreferenced by `synccli.py`. `DESIGN.md` (v2 daemon) is a separate goal and not part of this plan.
