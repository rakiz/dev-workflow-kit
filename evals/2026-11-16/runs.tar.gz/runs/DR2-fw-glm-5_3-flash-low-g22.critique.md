**Wrong assumptions**

1. **"mtime is guaranteed to change on every edit"** (line 58) — false. Whole-second mtime + 200ms debounce means two edits within the same second that end with identical size are invisible. With `snapshot()` storing whole seconds this isn't an edge case, it's the common case for fast edits. `dst` silently goes stale with no error. This alone invalidates the integrity story.
2. **"Latency at most 200ms"** (line 19) — contradicts the debounce rule itself: a file written continuously (log, long build output) never reaches a quiet period and is *never* copied. Burst coalescing and bounded latency can't both be true with restart-on-change semantics.
3. **"Second instance merges cleanly"** (line 47) — two daemons in the lock-release→commit window are both scanning *and both copying into dst* concurrently, cycle after cycle (each releases before committing, so the other can always grab the lock). "Merge cleanly" assumes idempotent copies, but concurrent writes to the same dst file can interleave/truncate. Hold the lock across the commit — the fix is free.

**What breaks under real load**

4. **Truncated dst copies**: the re-stat check (line 25) only catches a *source* change — a crash mid-copy still leaves a partial file in dst, and there's no tmp+rename for the *data* copy (only rejected for the manifest). Post-copy stat ≠ atomic write.
5. **Mass-deletion wipe**: an unmounted/network src looks identical to "all files deleted"; reconcile deletes all of dst on the next poll. Need a threshold (e.g. refuse to delete >N% in one pass).
6. **The 100ms scan figure is warm-cache.** Every 500ms you stat 50k files; on cold cache or a network volume this is seconds, cycles fall behind, and the pending dict "bounded by one poll's worth of changes" (line 23) grows without bound — the bound is circular (it assumes the poll keeps up).
7. **Journal never compacted** — unbounded growth on a long-running daemon; and nothing says it's fsynced, so the "loses nothing" claim (line 32) is soft.

**Change first**

- Store mtime at nanosecond resolution (or hash changed-size-same-mtime files) — biggest correctness win, cheap.
- Atomic manifest write via tmp+rename anyway; the fsync cost argument is about the *journal* cadence, and losing the repair-path assumption simplifies everything.
- Hold the PID lock for the whole cycle.
- Add a deletion-safety threshold and a dst atomic write.
