Read `GOAL.md`, `README.md`, and the four code/design files (`synccli.py`, `incremental.py`, `test_synccli.py`, `DESIGN.md`), and ran the baseline suite read-only. Plan below — **no files modified**.

## Baseline facts that shape the plan
- `sync()` (synccli.py:72) returns only `copied`; `main()` (synccli.py:90) prints one path per line — that is the only stdout today.
- `--dry-run` already exists and returns `to_copy` without writing.
- `json` is already imported in synccli.py — no new dependency needed.
- `copy_file` (synccli.py:62) silently swallows `OSError` (`pass`), so a "copied" path can be in the returned list even when the write failed.
- **Baseline is already red**: `test_first_item_stale_is_included` fails (`collect_stale` starts at `range(1,...)` and drops item 0). Pre-existing, unrelated to this goal.

## Open design decisions (must be resolved before impl)
1. **Definition of `skipped`**: files in src NOT in `copied` (= total scanned − copied)? Or only "already up-to-date"? Affects dry-run too.
2. **src/dst values**: echo CLI args verbatim vs. normalized/absolute paths.
3. **Failed copies**: accept that `copied` is "attempted" (existing silent-swallow behavior), or is accurate reporting in scope? GOAL doesn't require it.
4. **Pre-existing red test**: leave untouched (out of scope) vs. fix — needs explicit user yes.

---

## Task 1 — Scope confirmation & baseline map
- **Objective**: Confirm all call sites of `sync()`, current stdout/stderr behavior, and test conventions before touching code.
- **Files**: read `synccli.py`, `incremental.py`, `test_synccli.py` (no writes).
- **Agent**: `explore`
- **Risks**: Missing a hidden internal caller of `sync()` that a signature change would break (mitigated because we will not change the signature).
- **Acceptance**: Written inventory of every `sync(` caller and every `print(` in the package; explicit statement that `main()` is the only stdout writer.

## Task 2 — Design review of JSON contract
- **Objective**: Settle decisions 1–3 above; specify exact schema, stdout purity rule, dry-run semantics, exit-code behavior, and the `sync()`-signature-stable constraint.
- **Files**: read-only (`synccli.py`, `GOAL.md`).
- **Agent**: `design-review` (cheap-design-review)
- **Risks**: Ambiguous `skipped`/`src`/`dst` semantics leaking into tests and causing churn; conflict between "nothing else on stdout" and any future error logging.
- **Acceptance**: A signed-off contract listing: `{"copied": list[str], "skipped": int, "src": str, "dst": str}`, the exact `skipped` formula, dry-run rule, and "no other stdout in JSON mode".

## Task 3 — Implement `--json` in `main()`
- **Objective**: Add the flag and JSON emission without changing `sync()`'s signature.
- **Files**: `synccli.py` (modify `main()`; optionally a small pure helper to build the payload).
- **Agent**: impl (`cheap-code`)
- **Risks**: Accidental stdout leakage; changing `sync()` signature (forbidden); computing `skipped` needing total count without re-scanning inconsistently; mistaking "attempted" for "copied".
- **Acceptance**: `python3 -m synccli --json SRC DST` prints exactly one valid JSON object with all four keys and nothing else on stdout; exit code 0; human mode output byte-identical to before.

## Task 4 — Unit tests for JSON shape
- **Objective**: Cover valid JSON, key presence/types, and dry-run semantics.
- **Files**: `test_synccli.py` (append test class).
- **Agent**: impl (`cheap-code`) — same session as Task 3
- **Risks**: Coupling tests to unspecified `skipped` semantics; not asserting stdout purity (parsing only); mutating real temp dirs across tests.
- **Acceptance**: New tests assert: `json.loads(stdout)` succeeds; keys `copied/skipped/src/dst` present with correct types; `--dry-run --json` lists would-copy paths and does not write to dst; suite has **no new failures** vs. the known baseline failure.

## Task 5 — Code review of implementation + tests
- **Objective**: Verify contract compliance, stdout purity, signature stability, stdlib-only, and test adequacy.
- **Files**: read-only diff of `synccli.py`, `test_synccli.py`.
- **Agent**: review (`cheap-review`)
- **Risks**: Reviewer treats the pre-existing red test as a regression; missing an edge case (empty src, no changes on second run).
- **Acceptance**: Findings classified minor/major; zero unresolved majors; explicit confirmation the only failing test is the pre-existing one.

## Task 6 — Final verification & smoke test
- **Objective**: Run the full suite and a manual CLI smoke test in both modes.
- **Files**: none (execution only).
- **Agent**: impl/orchestrator (`cheap-code` runs, verdict to user)
- **Risks**: Environment py3.10 mismatch; manual smoke leaving temp files.
- **Acceptance**: `python3 -m unittest -v` shows only the pre-existing `collect_stale` failure; `--json` output parses and human output matches prior behavior; report states decisions 1–4 resolution.

---

**Blocking prerequisite before Task 3**: the user must resolve decisions 1–4 (especially the `skipped` definition and whether to fix the pre-existing red test). I have made no changes; say the word and I'll run this pipeline.
