## Blockers (change before writing code)

**1. Per-poll manifest read-modify-write is the real cost, not the scan.**
`run()` does `load_manifest` → `update` → `commit_manifest` every 500 ms (syncd.py:68-70). At 50k entries that's a multi-MB JSON parse + full rewrite twice a second, in memory and on disk — ~10–20 MB/s of constant churn at idle, and GC pressure that eats the "ample headroom" the design assumes. Fix: keep the manifest in memory; flush atomically (tmp + `os.replace` + `fsync`) only when it changed or on a slow cadence.

**2. Whole-second mtime + size as the change key is wrong, and one of the stated assumptions is false.**
`int(st.st_mtime)` (state.py:19) and "mtime is guaranteed to change on every edit" are both wrong: two edits in the same second with equal size are missed *forever*; `cp -p`, `rsync -t`, `tar`, git checkout, and many build tools preserve mtime. Use `st_mtime_ns` + size at minimum, and state that mtime-preserving writers are unsupported (or hash on suspicion). `--verify` inherits the same blind spot and will happily report clean while stale.

**3. Lock is broken in three ways.**
`acquire_lock` is check-then-create (state.py:40-43) — TOCTOU; a `kill -9` leaves a stale file that blocks every future start (no PID liveness check); and releasing before the manifest commit (DESIGN:44-48) contradicts "exactly one daemon ever writes into `dst`": two instances then do concurrent read-modify-write of the same manifest → lost updates and resurrected deletions. Use `O_CREAT|O_EXCL` or `fcntl.flock` held for process lifetime, with PID/start-time liveness.

**4. Journal can't replay what it never recorded.**
Only copies are journaled (state.py:51-54); deletions have no tombstone, so a crash before manifest commit resurrects deleted entries. No `fsync` anywhere, so "loses nothing" fails on power loss. GOAL item 3 (compaction) is then unsafe without strict ordering: fsync manifest → truncate journal. Add record types (create/delete) and the ordering before implementing compaction.

## Wrong assumptions to correct in the doc

- **"dst never holds a truncated copy"** — `open(dst,"wb")` truncates in place; dst is truncated *during* every copy and stays truncated if the daemon dies mid-copy. The re-stat check doesn't help. Write a tmp file in the destination dir + `os.replace`.
- **"Pending bounded by one poll's worth"** — a continuously rewritten file never reaches its quiet period; `pending`/`quiet_since`/`observed` grow during long bursts, and `observed`/`synced` are never pruned on delete → unbounded memory over days. `f.read()` of whole files adds an OOM path on large artifacts.
- **Debounce "at most 200 ms even while written continuously"** — false; continuous writers are never synced. Say "at most 200 ms after the last write."
- **Deletion is treated as unconditionally safe** — a transient source problem (unmounted share, permission error, scan race) deletes the whole of `dst`. Gate deletions on a clean, complete scan; otherwise skip the reconcile.

## What breaks under real load

- Single-threaded copy loop: copies block scanning, so one large file stalls detection for everything; a few-hundred-file burst collapses the 500 ms cadence and latency grows without bound — exactly the case the design claims to handle.
- The 100 ms scan estimate fails on NFS/spinning media/cold cache and on dirs with large `os.walk` fan-out; a fixed 500 ms constant gives no escape hatch there.
- Unhandled entirely: file mode/permissions (copy doesn't preserve), symlinks (`os.stat` follows), empty directories, partial/atomic-rename builds (thrash delete+create).

## Change order

1. Manifest I/O model (in-memory, atomic, fsync, change-only flush).
2. Change key → `st_mtime_ns` + size; document the mtime-preserving limitation.
3. Lock correctness (atomic, lifetime-held, stale-safe).
4. Atomic destination writes + deletion gating.
5. Journal tombstone record + compaction ordering.

Everything else (poll vs. watchers, debounce tuning) is a reasonable trade-off once #1–#4 stop silently losing or corrupting data.
