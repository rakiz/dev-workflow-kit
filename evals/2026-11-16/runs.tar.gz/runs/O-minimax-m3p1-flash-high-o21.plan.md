Read GOAL.md, README.md, DESIGN.md, plus the code (`synccli.py`, `incremental.py`, `test_synccli.py`). Current state: 6 tests, **1 already failing** (`test_first_item_stale_is_included` — `collect_stale` loops `range(1, len(items))`, so it drops the first element). That is a pre-existing bug outside GOAL scope, but it will block a "all tests green" acceptance criterion, so it appears below as a gated task.

---

# Execution plan — JSON output mode + dry-run UX

**Repo facts driving the plan**
- `sync(src_root, dst_root, dry_run=False) -> list[str]` (synccli.py:72) already returns the *selection* of files to copy, and in dry-run returns it without copying (synccli.py:81-82). So "copied" = *selection*, and dry-run "WOULD be copied" needs no new plumbing — only that the value must reach the JSON output.
- `copy_file` swallows `OSError` (synccli.py:68-69), so a listed file may not actually land on disk. This is the one real semantic trap: `copied` must be defined identically in real mode and dry-run mode (the "selection" definition) or the two modes contradict each other.
- `json` is already imported; no new deps needed. `incremental.py` imports `copy_file` only — `sync()` has no in-repo caller today, but the GOAL constraint still applies.

**Roles**: `explore` → `cheap-design-review` → `cheap-code` (impl) → `cheap-review` (review, mandatory) → optional gated fix.

---

### T1 — Ground-truth exploration and semantics decision record
- **Objective**: confirm every stdout writer, every `sync()`/`copy_file()` call site, the exact difference between dry-run and real-run returns, and draft the semantic decisions the impl needs (see below). Produce a written decision record, no code.
- **Files**: none modified. Read: `synccli.py`, `incremental.py`, `test_synccli.py`, `GOAL.md`, `DESIGN.md`, `README.md`.
- **Agent**: `explore`
- **Decisions to draft (with recommendation)**:
  1. `copied` = *set of source-relative paths selected for copying* (real mode: selected-and-copied; dry-run: would-be-copied). Rationale: identical definition in both modes, matches GOAL item 2 wording.
  2. `skipped` = number of scanned source files not in `copied` (i.e. unchanged files, plus — under decision 1 — any file whose copy silently failed, which keeps the count truthful). Alternative considered and rejected: "skipped = unchanged only", which would let `copied` overstate reality given the swallowed `OSError`.
  3. `src`/`dst` = the exact CLI argument strings as typed (`args.src`, `args.dst`), not `abspath` — echo what the user asked for.
  4. JSON mode emits **exactly** the four keys `copied`, `skipped`, `src`, `dst`; no extra keys (GOAL names the object explicitly; a test asserts key presence, extra keys invite rejection).
  5. Any new diagnostic output (e.g. copy failures) goes to **stderr**, never stdout, in both modes; stdout purity is a hard requirement.
  6. Exit code remains `0` on the normal path, in both modes; error paths (e.g. corrupt manifest) keep today's exception behavior — unchanged.
- **Risks**: none (read-only). Failure mode is a vague record → the design review catches it.
- **Acceptance**: decision record lists all 6 items with a chosen value and one-line rationale, names every current stdout write site, and states whether `sync()`'s public return value stays byte-identical.

---

### T2 — Design review / spec sign-off
- **Objective**: review the T1 decision record against GOAL.md's four requirements and its constraints (no new dependencies, Python 3.10 stdlib only, `sync()` signature stable, human mode unchanged) and ratify or correct it into the spec the impl must follow.
- **Files**: none modified (review output only; spec recorded in the T3 brief).
- **Agent**: `cheap-design-review`
- **Risks**:
  - Over-design: the change is small; the review must reject machinery that isn't needed (no new classes, no argparse overhaul, no config files).
  - Under-specification: if `skipped` or the `copied` definition is left ambiguous, the impl and the tests will diverge.
- **Acceptance**: a single approved spec stating (a) the exact JSON schema and key set, (b) the exact `copied`/`skipped` definitions, (c) the stdout/stderr split, (d) the approved public API of `synccli.py` showing `sync(src_root, dst_root, dry_run=False)` keeps its signature **and** its current list return value, (e) the exact list of tests to be added. No unresolved item left open.

---

### T3 — Implementation
- **Objective**: implement the approved spec in `synccli.py` — add `--json`, emit the JSON object, keep human mode and `sync()` intact.
- **Files**: modify `synccli.py` only.
  - Add `--json` (`action="store_true"`) to the existing parser (synccli.py:91-95).
  - Add one new function alongside `sync()` — e.g. `sync_report(src_root, dst_root, dry_run=False) -> dict` — returning `{"copied": [...], "skipped": N, ...}`; implement `sync()` as a thin wrapper returning only `result["copied"]` so its signature **and** current return semantics are unchanged for any external/internal caller.
  - `main()`: in `--json` mode print **one** `json.dumps(...)` object to stdout and nothing else; otherwise keep the existing `for rel in copied: print(rel)` loop exactly as is (one path per line). Keep `return 0`.
  - Stdlib only (`json` already imported); no changes to `incremental.py` unless T2 explicitly requires it.
- **Agent**: `cheap-code`
- **Risks**:
  - Breaking `sync()`'s contract → internal/external callers silently change behavior. Mitigation: `sync()` delegates but returns the same list type/content.
  - stdout pollution in JSON mode (a stray `print`, a warning, a library traceback on stdout). Mitigation: single `print` call, everything else to stderr.
  - Double scanning: computing `skipped` must not re-walk the tree (re-scanning yields a *different* file set under concurrent edits and doubles I/O on 50k-file trees). Mitigation: derive `skipped` from the manifest the sync already built.
  - Accidentally changing human-mode membership of the printed list (the silent-`OSError` case). Mitigation: mirror the spec's `copied` definition exactly.
  - Overwriting `dst` manifest in dry-run → the dry-run must not write `.sync_manifest.json`. Mitigation: preserve the early return at synccli.py:81-82 semantics.
- **Acceptance** (all verifiable, no hidden state):
  1. `python3 -m synccli --help` lists both `--dry-run` and `--json`.
  2. Human mode: `python3 -m synccli SRC DST` prints exactly the relative paths, one per line — byte-identical to pre-change behavior for the same fixture (verified against `git stash`-free comparison of the two command outputs).
  3. `python3 -m synccli SRC DST --json` prints a single line that `json.loads()` parses, whose keys are exactly `{copied, skipped, src, dst}`.
  4. `python3 -m synccli SRC DST --json --dry-run` prints `copied` = the files that *would* be copied, and the destination directory contains **no** copied files and **no** `.sync_manifest.json` afterwards.
  5. `python3 -m synccli SRC DST --json` (no dry-run) has `copied` equal to the files present in `DST` afterwards, and `skipped == total_scanned - len(copied)`.
  6. `python3 -c "import synccli, inspect; print(inspect.signature(synccli.sync))"` still shows `(src_root, dst_root, dry_run=False)`; `synccli.sync(src, dst)` still returns a `list` of relative paths.
  7. Exit code is `0` in modes 2-5.

---

### T4 — Unit tests for the JSON shape (continuation of the same impl instance)
- **Objective**: add the tests GOAL item 4 requires, to `test_synccli.py`.
- **Files**: modify `test_synccli.py`.
  - New `TestJsonOutput` class using `tempfile.mkdtemp()` fixtures (match the existing style at test_synccli.py:36-40) and `contextlib.redirect_stdout` + `io.StringIO` to capture stdout — no subprocess, no new dependency.
  - Cases: (a) `--json` alone → output parses as JSON, key set exactly `{copied, skipped, src, dst}`, `copied == ["a.txt"]`, `skipped` is an int; (b) `--json --dry-run` → `copied == ["a.txt"]` while the destination stays empty and no manifest is written; (c) second run after a sync → `copied == []` and `skipped` counts the unchanged file; (d) stdout purity → the captured stdout contains exactly one JSON document and nothing else (no extra line, no trailing diagnostic); (e) human mode unaffected → stdout is one path per line.
- **Agent**: `cheap-code`, **resumed as the same instance as T3** (same feature, same files, retains the spec and code context) — not a fresh session.
- **Risks**:
  - Tests that assert only `keys present` pass while the values are wrong → assert exact values, not just membership.
  - Tests coupled to `os.sep` / platform path separators → use `os.path.join` like the existing test at test_synccli.py:18.
  - The pre-existing failing test (§ T6) may make "all tests green" unattainable → the acceptance criterion for T4 must be scoped to the new tests plus "no previously-passing test regressed".
- **Acceptance**: `python3 -m unittest -v` shows the new JSON tests all passing, every previously-passing test still passing, and the number of failures equals the pre-existing count (1) until T6 is approved.

---

### T5 — Mandatory implementation review
- **Objective**: review the T3+T4 diff for correctness against the T2-approved spec, and classify findings as minor (fix in place) or major (escalate).
- **Files**: read `synccli.py`, `test_synccli.py`; write the review verdict only (no edits by the reviewer).
- **Agent**: `cheap-review`
- **Review focus (explicitly briefed)**:
  1. Does `--json` mode ever write anything else to stdout (including via exceptions/warnings)?
  2. Is `skipped` computed from the same scan as `copied` (no second walk, no stale snapshot)?
  3. Is `sync()`'s signature **and** return value unchanged, and does `sync_report`/equivalent add any risk to it?
  4. Is human mode genuinely unchanged (same lines, same order, same membership)?
  5. Is dry-run still side-effect-free (no manifest write, no file copies)?
  6. Stdlib-only, Python 3.10 compatible, no new dependency.
  7. Do the tests assert *values*, or only key presence?
  8. Any accidental behavior change to `copy_file` / `incremental.py` importers.
- **Risks**: a green test run masking a spec deviation (e.g. `skipped` semantics) → the reviewer must check against the T2 spec, not against the tests. Reviewer context must be self-contained (the T2 spec must be restated in the brief, not referenced by pointer to a previous session).
- **Acceptance**: a verdict of "approve" or a list of classified findings; every minor finding fixed and re-verified in the same impl instance; the final `python3 -m unittest -v` failure count is unchanged from the pre-existing baseline (1) and the 7 acceptance checks of T3 are re-run and pass verbatim.

---

### T6 — Gated, out-of-scope fix (requires explicit user approval)
- **Objective**: fix the pre-existing bug that makes the suite red before this release: `collect_stale` starts at `range(1, len(items))` (synccli.py:55) and therefore never reports the first item as stale, while the test at test_synccli.py:24 expects it to be included.
- **Files**: modify `synccli.py` (`collect_stale`) and, only if the semantics are confirmed to be "first item included", `test_synccli.py` (test at line 24 should then pass unmodified).
- **Agent**: `cheap-mech` (mechanical, one-line) — or `cheap-code` if the reviewer judges the intended semantics ambiguous.
- **Risks**: `collect_stale` is unused in-repo, so a fix is behaviorally inert here, but if external callers rely on the current off-by-one, the fix changes their results. Also the same file/function may be relied upon by the not-yet-written v2 daemon (DESIGN.md).
- **Acceptance**: `python3 -m unittest -v` → 0 failures, all 6 original + the new JSON tests passing; `collect_stale` includes the first item and still respects `seen=` and the `fresh` flag.
- **Gate**: **do not execute without explicit user approval** — it is outside GOAL.md's scope and the GOAL asks for a specific change only. If not approved, T4/T5's acceptance stays "no new failures, pre-existing failure unchanged", and the release note must state the red baseline.

---

### Task order and dependencies
```
T1 (explore) → T2 (design-review) → T3 (impl) → T4 (impl, same instance) → T5 (review) → [T6 gated]
```
T6 may be pulled forward (before T3) if approved, so the suite is green before the feature lands; it is otherwise independent of T1-T5.

### Global risks (plan-level)
| Risk | Mitigation |
|---|---|
| Ambiguity of `skipped` is the single largest source of rework | Resolved once in T2, frozen into the T3 brief |
| stdout purity broken by an unforeseen `print`/warning | T5 focus #1 + a dedicated stdout-purity test in T4 |
| `sync()` contract broken for hidden callers | T3 keeps `sync()` as a delegating wrapper; T5 focus #3 verifies signature and return type |
| Pre-existing red test muddies "done" | Isolated in T6 behind an approval gate; baseline failure count is part of every acceptance criterion |
| Scope creep from DESIGN.md's v2 daemon | DESIGN.md is a *different* release (daemon `syncd`); explicitly out of scope for this plan — no daemon code is planned here |

**No files were modified.**
