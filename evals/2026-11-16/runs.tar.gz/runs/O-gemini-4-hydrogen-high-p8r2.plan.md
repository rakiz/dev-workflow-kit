### Execution Plan: `--json` Output Mode & `--dry-run` UX

---

#### Task 1 — Codebase & Contract Exploration
- **Objective:** Confirm all callers of `synccli.sync`, `main`, and CLI entry points (`python3 -m synccli`), verify Python 3.10 runtime and current test baseline (`python3 -m unittest -v`), and resolve edge-case semantics for the JSON payload (`skipped` count definition: unchanged manifest entries vs. unreadable files; `src`/`dst` string normalization; `dst` directory/manifest non-existence on `--dry-run`).
- **Files to create/modify:** None (read-only).
- **Pipeline agent:** `explore`
- **Risks:**
  - Misinterpreting `skipped` (e.g., `total_src_files - len(copied)` vs. `OSError` read skips in `copy_file`) could produce wrong counts in JSON output.
  - Pre-existing unrelated test failure in `test_synccli.py` (`TestCollectStale.test_first_item_stale_is_included` hits `range(1, len(items))` in `synccli.py:55`) could obscure baseline test status if not documented upfront.
- **Verifiable acceptance criterion:** Written report confirming (1) exact list of internal `sync()` callers, (2) baseline output of `python3 -m unittest -v`, and (3) documented semantics for `"copied"`, `"skipped"`, `"src"`, and `"dst"`.

---

#### Task 2 — Design Review of `--json` & `sync()` Stability
- **Objective:** Validate the minimal design before editing code: keeping `sync(src_root, dst_root, dry_run=False) -> list[str]` unchanged in signature and return type while exposing skipped count to `main()` (e.g., via an internal helper `_sync(...)` used by both `sync()` and `main()`, so `main()` does not double-scan `src_root` or diverge from `sync()`).
- **Files to create/modify:** None (design critique only; no files modified).
- **Pipeline agent:** `design-review` (`cheap-design-review`)
- **Risks:**
  - Calling `scan_files()` separately in `main()` after `sync()` introduces TOCTOU drift and double I/O.
  - Modifying `sync()`'s return value or adding required parameters would break internal callers (`DESIGN.md` notes `syncd` reuses `sync()` directly).
  - Printing anything else to `stdout` (warnings/logs) when `--json` is set breaks machine-readable parsing.
- **Verifiable acceptance criterion:** Approved design note specifying (1) unchanged `sync(src_root, dst_root, dry_run=False)` contract, (2) exact JSON schema `{"copied": list[str], "skipped": int, "src": str, "dst": str}`, and (3) confirmation that `os.makedirs` / manifest writes remain skipped under `--dry-run`.

---

#### Task 3 — Implement `--json` Flag and `--dry-run` Interplay
- **Objective:** Add `--json` flag to `argparse` in `main()`, refactor `sync()` to delegate to an internal helper (or equivalent) that preserves `sync(src_root, dst_root, dry_run=False)` while providing `skipped` count to `main()`, and emit a single `json.dumps({"copied": ..., "skipped": ..., "src": ..., "dst": ...})` line to `stdout` when `--json` is passed while keeping human mode (`one path per line`) and exit codes unchanged.
- **Files to create/modify:**
  - Modify: `synccli.py`
- **Pipeline agent:** `impl` (`cheap-code`; escalate to `strong-code` only on demonstrated stall or major review finding)
- **Risks:**
  - Breaking `sync()` signature, default args, or return value (`list[str]`).
  - Writing to `dst` or creating `.sync_manifest.json` during `--dry-run --json`.
  - Accidental extra `stdout` output in `--json` mode, or breaking human mode formatting when `--json` is omitted.
  - Introducing non-stdlib or >Python 3.10 imports/syntax.
- **Verifiable acceptance criterion:**
  - `python3 -m synccli --help` shows `--json`.
  - `python3 -m synccli <src> <dst> --json` and `python3 -m synccli <src> <dst> --json --dry-run` each print exactly one valid JSON object on `stdout` with keys `copied`, `skipped`, `src`, `dst`, exit code `0`, and `--dry-run` leaves `<dst>` unmodified.
  - `synccli.sync(src, dst, dry_run=...)` signature and `list[str]` return value are unchanged.

---

#### Task 4 — Add Unit Tests for JSON Mode and Dry-Run Semantics
- **Objective:** Add unit tests to `test_synccli.py` covering `--json` output validity (`json.loads` succeeds with single object on `stdout`), required keys (`copied`, `skipped`, `src`, `dst`) and types, `--json --dry-run` listing would-be copied files without modifying `dst` or creating `.sync_manifest.json`, subsequent `--json` sync reporting `copied == []` and `skipped > 0`, and regression check that human mode still outputs one path per line.
- **Files to create/modify:**
  - Modify: `test_synccli.py`
- **Pipeline agent:** `impl` (`cheap-code`, or `cheap-mech` if purely mechanical following existing `unittest` pattern in `test_synccli.py`)
- **Risks:**
  - Tests mutating or leaking temp directories, or asserting platform-specific path separators instead of `os.path.join`.
  - Tests calling `main()` directly without capturing `stdout` cleanly (`io.StringIO` / `contextlib.redirect_stdout`).
- **Verifiable acceptance criterion:** New `unittest` test methods in `test_synccli.py` pass via `python3 -m unittest -v test_synccli` (all JSON/sync/scan tests pass; any pre-existing unrelated `TestCollectStale` failure is explicitly noted and untouched).

---

#### Task 5 — Independent Code Review & Final Verification
- **Objective:** Audit the diff across `synccli.py` and `test_synccli.py` against all `GOAL.md` requirements and constraints (Python 3.10 stdlib only, no new dependencies, `sync()` signature stability, human mode untouched, no unrelated edits to `incremental.py` or `collect_stale`, clean test execution).
- **Files to create/modify:** None (read-only audit; minor fixes route back to `cheap-code`, major findings escalate to `strong-code`).
- **Pipeline agent:** `review` (`cheap-review`; escalate to `strong-review` only if `strong-code` was invoked)
- **Risks:**
  - Unnoticed edge cases: empty `src` directory (`copied: []`, `skipped: 0`), `dst` not yet existing under `--dry-run --json`, or `argparse` error handling/exit codes.
  - Scope creep into `incremental.py` or `DESIGN.md`.
- **Verifiable acceptance criterion:** Review verdict `APPROVE` with zero major/minor open findings, `git diff --stat` showing only `synccli.py` and `test_synccli.py`, and passing `python3 -m unittest` verification output for all `TestScanFiles`, `TestSync`, and new JSON CLI tests.
