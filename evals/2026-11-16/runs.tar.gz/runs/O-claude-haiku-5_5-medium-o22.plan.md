## Execution plan: `--json` output and dry-run UX for synccli

No files were modified. I read GOAL.md, README.md, `synccli.py`, `incremental.py` and `test_synccli.py`. I did not run the test suite, so the baseline is unverified (T0 covers it).

### Findings that shape the plan

- `sync()` returns only the list of copied paths. `skipped` must be derived as `len(src_manifest) - len(copied)`, so `sync()` internals need a richer return path while its signature stays the same.
- `main()` prints one path per line and always returns 0. The JSON mode must print exactly one object and keep that exit code.
- `dry_run=True` already returns the would-copy list without writing files or the manifest. The `--dry-run` + `--json` semantics mostly exist already.
- **Pre-existing failure:** `collect_stale` uses `range(1, len(items))`, which skips the first item. `test_first_item_stale_is_included` expects `x.txt` in the result, so it should fail. Not in scope; flagged only.
- **Pre-existing risk:** `copy_file` swallows `OSError`, yet `sync()` still writes the manifest. A file that failed to copy is recorded as synced, so `copied` in JSON could list files that were never copied. This needs a decision (see open questions).
- `incremental.py` is not imported by `synccli.py`. It has a mutable default argument (`excluded=[]`) in `filter_excluded`. Out of scope; flagged only.

---

### T0. Baseline capture
- **Objective:** Record the current test results and the call sites of `sync()` and `main()` before any change.
- **Files:** none (read-only).
- **Agent:** `explore`
- **Risks:** the baseline may already contain failures, which would be wrongly attributed to this work later.
- **Acceptance:** a list of pass/fail per test from `python3 -m unittest -v`, with the expected `test_first_item_stale_is_included` failure confirmed or refuted. Also a list of every `sync(` and `main(` caller in the repo.

### T1. Design note (optional, recommended)
- **Objective:** Fix the JSON contract and the internal API before code exists:
  - `skipped` = `len(src_manifest) - len(copied)`
  - whether `src`/`dst` are the raw CLI strings or absolute paths
  - the internal function that returns `{copied, skipped}` (for example `sync_report(src, dst, dry_run)`), with `sync()` as a thin wrapper that returns the list.
- **Files:** a short design section in the task thread only. No new doc file.
- **Agent:** `cheap-design`, then `cheap-design-review`. Skip the review if the design stays as small as the points above.
- **Risks:** a `sync()` wrapper that changes behaviour for internal callers.
- **Acceptance:** written decisions on the three points above, and a reviewer confirmation that `sync(src_root, dst_root, dry_run=False)` keeps its exact signature and return type.

### T2. Internal refactor for the report
- **Objective:** Add the function that returns `copied` and `skipped`. Make `sync()` delegate to it and still return the list.
- **Files to modify:** `synccli.py` (`sync` and the new helper only).
- **Agent:** `cheap-code`, then `cheap-review`.
- **Risks:** changing the manifest-writing order, or the non-dry-run side effects.
- **Acceptance:**
  - `inspect.signature(synccli.sync)` is unchanged.
  - Existing `TestSync` tests give the same results as the T0 baseline.
  - `skipped + len(copied) == number of src files` in a manual check.

### T3. `--json` flag in `main()`
- **Objective:** Add `--json`. When set, print one `json.dumps` object with keys `copied`, `skipped`, `src`, `dst` and nothing else on stdout. Keep the human path unchanged. Keep the exit code at 0.
- **Files to modify:** `synccli.py` (`main` and the argparse setup only).
- **Agent:** `cheap-code`, then `cheap-review`.
- **Risks:**
  - Any stray print, including debug output, breaks the "nothing else on stdout" rule.
  - Option name collision with `--dry-run`.
  - Non-ASCII paths: `json.dumps` escapes them by default, which is valid JSON.
- **Acceptance:**
  - `python3 -m synccli SRC DST --json | python3 -c "import json,sys; json.load(sys.stdin)"` succeeds.
  - `python3 -m synccli SRC DST` (no flag) prints one path per line, as before.
  - Exit code is 0 in both modes.

### T4. Tests for the JSON shape and dry-run semantics
- **Objective:** Add tests to `test_synccli.py` covering:
  - stdout parses as a single JSON object (capture with `contextlib.redirect_stdout` and call `main([...])`)
  - the four keys are present with the right types
  - `skipped` matches the expected count
  - `--dry-run --json`: `copied` lists the would-copy files, `dst` gets no files, and no manifest is written
  - the human mode prints one path per line
- **Files to modify:** `test_synccli.py` only.
- **Agent:** `cheap-code`, then `cheap-review`.
- **Risks:** tests that assert on the current wrong `collect_stale` behaviour. Tests must not depend on the pre-existing failure. Temp dirs must be cleaned up.
- **Acceptance:** all new tests pass with `python3 -m unittest -v`. The only failure in the run is the pre-existing one from T0, unchanged.

### T5. Compatibility check (Python 3.10, stdlib only)
- **Objective:** Confirm no new dependency and no syntax or API beyond Python 3.10.
- **Files:** none (read-only), unless a fix is needed, which goes back to T2 or T3.
- **Agent:** `explore`
- **Risks:** a 3.11+ API slipping in. If no 3.10 interpreter is installed, the check is only partial.
- **Acceptance:** `python3.10 -m unittest` runs with the same results as T0, or the sandbox has no 3.10 and this is reported as not verified.

### T6. Final audit
- **Objective:** Check the full diff against each GOAL.md point and constraint:
  - single JSON object on stdout in JSON mode
  - dry-run semantics
  - human mode unchanged
  - tests added
  - no new deps
  - `sync()` signature stable
- **Files:** none (read-only).
- **Agent:** `strong-review` (or `strong-review-alternative` if the Claude-family implementer produced most of the diff). Escalate only on a major finding.
- **Risks:** the reviewer re-litigates pre-existing bugs outside scope.
- **Acceptance:** a checklist with each GOAL point marked pass or fail with evidence, and no major findings open.

---

### Out of scope (flag only, do not change without an explicit yes)
- `collect_stale` skips the first item and makes its own test fail.
- `copy_file` swallows errors but the manifest is still written, so `copied` can overstate what was copied.
- `filter_excluded(paths, excluded=[])` has a mutable default argument.
- `incremental.py` is not wired into the CLI.
- README does not mention `--json`. Updating it would be an adjacent change and needs your approval.

### Open questions for you
1. Should `copied` in JSON reflect only files that were actually copied? If yes, `copy_file` must report failure, which changes `sync()` behaviour (and is a fix beyond GOAL.md).
2. Should `src`/`dst` be the raw CLI strings or resolved absolute paths?
3. Is the README update wanted in this release?
