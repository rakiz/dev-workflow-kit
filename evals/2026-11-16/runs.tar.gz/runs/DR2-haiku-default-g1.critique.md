## Critique of DESIGN.md (syncd v2)

The design is not ready to implement. Several central guarantees are contradicted by its own mechanisms.

**Blocking issues**

1. **Debounce can starve forever.** Each observed change restarts the 200 ms quiet period with no maximum wait. A file that is written continuously (a log, a build artifact, a watched output) never syncs, yet the doc claims latency stays "under one poll plus 200 ms even while a file is being written continuously." That claim is false. Add a max-wait cap (for example, force a copy after 2 s of churn).

2. **The mtime check misses edits.** mtime is stored at whole-second resolution. Two edits to the same file within one second with the same size produce identical `(size, mtime)`, so the second edit is never copied. The doc says "mtime is guaranteed to change on every edit," which is not true at this resolution. Use `st_mtime_ns` and include `st_ctime_ns` or inode. Note the rejected-alternatives section also depends on this claim.

3. **The single-instance guarantee is broken.** The lock is released before the manifest commit, and a second instance can start in that window. Its scan runs against a stale manifest, so it can delete files in `dst`. The doc argues the commit "merges cleanly," but the manifest is rewritten in place, which is last-writer-wins, not a merge. Hold an `flock` on an open fd for the process lifetime. A PID file also goes stale after a crash.

4. **Backpressure bound is wrong.** Under debounce, files stay pending across polls while their quiet period keeps restarting. The pending set is bounded by the number of distinct files changing in a window, not by one poll's worth. Under a build burst of hundreds of files, memory and per-cycle work grow with churn duration.

5. **Journal and manifest can diverge on restart.** The journal records only copies, not deletions. If a file is copied, later deleted from `src`, and the process restarts before the manifest commit, replay resurrects its manifest entry. The doc also never says when the journal is truncated. As written it grows without bound, and every restart replays all of it.

**Unverified assumptions**

6. **Scan cost is asserted, not measured.** "Measured... well under 100 ms" is not backed by data in the doc. Python `os.walk` plus 50 000 `stat` calls on macOS, often cold after a build, is commonly 100–300 ms. At a 500 ms interval that is a large fraction of a core, and cycles will overlap or drift. Either measure it on the target machine and report the number, or change the interval to be relative to measured scan time.

7. **Atomic-save and checkout races are not handled.** Tools that delete then recreate files (git checkout, some formatters) can show a file as missing for one poll. Reconcile then deletes it from `dst`, and the next poll copies it back. Add a deletion grace period (for example, two consecutive misses).

8. **Manifest commit is not crash-atomic.** A rewrite in place can leave a truncated file. The doc relies on journal replay to repair it, but replay only works if the journal is complete and not yet truncated. Write the manifest to a temp file, fsync, and rename. The doc rejects this for write amplification, but a commit only per changed cycle is cheap enough to avoid that concern.

**Gaps**

9. Destination failures (disk full, permission denied, read-only volume) are not covered. Errors are handled only on the source side, and there is no backoff.
10. Symlinks, file modes, ignore rules (`.gitignore`-style, `.DS_Store`, `node_modules`), and xattrs are not mentioned. Any of these can turn a 50 000-file scan into a much larger one.
11. Rejecting inotify/FSEvents because overflow needs a rescan is weak. Overflow is a fallback case, not a reason to avoid watchers. The real cost is that polling is always O(tree size), and that deserves a stated number.

**Change first, in order**

1. Use `st_mtime_ns` plus `st_size` plus `st_ctime_ns` for change detection.
2. Add a max-wait cap to the debounce.
3. Hold a process-lifetime `flock` on the state directory.
4. Journal deletions, truncate the journal on each successful manifest commit, and write the manifest via temp file + fsync + rename.
5. Measure scan time on a 50 000-file tree on the target macOS machine and record the result in the doc.
6. Add a deletion grace period for atomic-save and checkout races.

Once these are settled, the rest of the design (polling, the rejected alternatives, the constant-based config) is reasonable for a single-workstation tool.
