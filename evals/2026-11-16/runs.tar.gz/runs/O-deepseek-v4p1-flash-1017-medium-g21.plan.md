Read `GOAL.md`, `README.md`, plus `DESIGN.md`, `synccli.py`, `test_synccli.py`, `incremental.py` for context. No repo changes made (test-run bytecode noise was restored).

## Baseline findings (drive the plan)

- `sync()` returns only `list[copied]` (`synccli.py:72`); the JSON `"skipped"` count is **not** available from it and must be derived without changing its signature.
- Existing suite is **already red**: `test_first_item_stale_is_included` fails because `collect_stale` iterates `range(1, len(items))` (`synccli.py:55`), skipping item 0.
- `copy_file` swallows `OSError` (`synccli.py:68`), so "copied" can include files that physically failed to copy.
- `DESIGN.md` is a separate v2 daemon proposal and proposes logging errors to **stdout** — directly conflicts with GOAL's "nothing else may be printed to stdout" if `syncd` ever reuses `main()`.

---

## Task 1 — Baseline verification & contract inventory
- **Objective:** Confirm the `sync()`/`main()` contract, the red-test cause, every stdout writer, and the exact derivation of `skipped`. Decide `src`/`dst` verbatim-string vs path normalization.
- **Files:** none (read-only).
- **Pipeline agent:** `explore`.
- **Risks:** Missing an indirect stdout write (e.g. argparse/usage) that would break the single-JSON-object guarantee.
- **Acceptance:** Written report stating: `sync(src_root, dst_root, dry_run=False)` signature/return, failing test name and root cause, inventory of all `print`/stdout sites, and chosen `skipped = len(scan_files(src)) - len(copied)` formula with justification.

## Task 2 — [NEEDS USER APPROVAL] Fix pre-existing red test
- **Objective:** Restore a green baseline so the release acceptance ("all tests pass") is achievable. Change `range(1, len(items))` → `range(len(items))` in `collect_stale`.
- **Files:** `synccli.py` (one line).
- **Pipeline agent:** `impl` → `review`.
- **Risks:** Out of literal GOAL scope; `collect_stale` is unused by `sync`/`main`, so behavior of the tool is unaffected, but it is still an adjacent change requiring explicit sign-off per policy.
- **Acceptance:** `python3 -m unittest -v` → 6/6 pass; `git diff` touches only that line.

## Task 3 — Implement `--json` + dry-run semantics
- **Objective:** Add `--json` to `main()`; emit exactly one JSON object `{"copied": [...], "skipped": N, "src": ..., "dst": ...}` on stdout, nothing else; with `--dry-run` `copied` is the would-be list and no files/manifest are written. Keep human mode byte-identical (one path per line), exit code unchanged, stdlib only, `sync()` signature untouched.
- **Files:** `synccli.py` (add arg, JSON branch; reuse `sync()` unchanged).
- **Pipeline agent:** `impl`.
- **Risks:** (a) `skipped` mis-defined when `copy_file` silently fails; (b) stray prints in JSON mode; (c) accidentally changing return/ordering of human mode; (d) any new dependency.
- **Acceptance:**
  - `python3 -m synccli SRC DST --json` stdout parses as one `json.loads`, keys exactly `copied, skipped, src, dst`, exit 0.
  - `--json --dry-run` lists would-be copies and writes nothing (no files, no manifest).
  - Human mode output identical to pre-change (diff against captured baseline).
  - `inspect.signature(synccli.sync)` unchanged.

## Task 4 — Add JSON tests
- **Objective:** Unit tests covering JSON shape, key presence, dry-run semantics, stdout purity, and human-mode invariance, appended to `test_synccli.py`.
- **Files:** `test_synccli.py`.
- **Pipeline agent:** `impl`.
- **Risks:** Tests that only assert substrings rather than parsing whole stdout (would not catch stray prints); tests coupled to tmp paths instead of normalizing.
- **Acceptance:** New tests fail against pre-change code and pass after Task 3; `python3 -m unittest -v` fully green.

## Task 5 — Implementation review
- **Objective:** Review the diff against GOAL constraints: single-object stdout, unchanged exit code, human mode unchanged, `sync()` signature stable, no new deps, Python 3.10 stdlib only, dry-run writes nothing.
- **Files:** none (read-only review of `synccli.py` + `test_synccli.py`).
- **Pipeline agent:** `review`.
- **Risks:** Reviewer misses `copy_file`'s silent-failure interaction with `copied`; missing a stdout leak in an error path.
- **Acceptance:** Written verdict (approve / minor / major) with file:line evidence; any major finding blocks release.

## Task 6 — [ADVISORY, OUT OF SCOPE] Design-review of `DESIGN.md`
- **Objective:** Critique the v2 daemon design for correctness and conflicts with this release: stdout error logging vs JSON purity, 500 ms full scan at 50k files, non-atomic in-place manifest rewrite, mtime+size-only detection, hardcoded interval, single-thread long-copy stall.
- **Files:** none (report only).
- **Pipeline agent:** `design-review`.
- **Risks:** Scope creep; must remain advisory and not gate the JSON release.
- **Acceptance:** Severity-ranked findings with concrete failure scenarios; explicit note that no daemon code is being changed.

**Order:** 1 → (2, gated) → 3 → 4 → 5; 6 runs in parallel and is non-blocking.
