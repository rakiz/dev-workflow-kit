## Critique of DESIGN.md (syncd v2)

**Blockers. Fix before writing code:**

1. **The single-writer guarantee is contradicted by the lock design.** The lock is taken per poll cycle and released before the manifest commit, and the doc argues a second instance can merge safely. But the Single instance section promises "exactly one daemon ever writes into `dst`." Two writers can race on deletes (one resurrects what the other removed) and on the manifest. Hold the lock for the daemon's lifetime and drop the merge argument.

2. **The debounce starves files that are being written continuously.** "Every further observed change restarts the quiet period" means a file that is still changing never becomes quiet, so it is never copied. The claim that latency stays "under one poll plus 200 ms even while a file is being written continuously" is false. Needs a max-wait cap (e.g., force a copy after 2 s of continuous change).

3. **Change detection misses real edits.** Size + mtime at whole-second resolution cannot see two edits in the same second that keep the same size. The 200 ms debounce makes this likely, not rare. Tools that preserve mtime (`cp -p`, `rsync -t`, `git checkout`) can also set it backwards. The claim that "mtime is guaranteed to change on every edit" does not hold. Store nanosecond mtime plus inode and ctime, or move to hashing for files whose metadata is ambiguous.

4. **Dst can hold partial files, and the integrity section does not cover it.** The copy goes straight to the final path, so any reader sees a truncated file during the copy. Write to a temp file in `dst` and `rename()` atomically. The re-stat check only detects source changes; it does not protect readers.

5. **The journal and integrity rules contradict each other.** The journal records a copy as "completed," but Integrity says a file is "never marked synced until a clean pass completes." Decide which marks a file synced and make the journal entry follow that point.

**Wrong or unsupported assumptions:**

6. **The scan budget is not supported.** "Well under 100 ms" for 50k stats is an unstated measurement. Cold cache, macOS Spotlight, or network volumes can push a Python `os.walk` plus `stat` to several hundred ms. A 500 ms poll that takes 300 ms is effectively continuous, using a full core-fraction and disk I/O. Measure cold and warm, and state the CPU budget.

7. **"Bounded pending set" is not bounded in time.** A poll drains every ready file serially. A burst of 500 large files can take many seconds, so the next poll is late, and the latency bound ("one poll plus 200 ms") does not hold. The memory bound is fine; the latency bound is not.

8. **The journal and manifest have no durability or growth story.** The journal is never compacted, so at a few changes per minute it grows without bound. Appends need fsync, or the "loses nothing" claim fails on power loss. The in-place manifest rewrite can leave a torn file, and "journal replay repairs it" only holds if the journal itself is complete and fsynced. Specify compaction (snapshot + truncate) and fsync points.

9. **Deletes are not safe on their own.** A file deleted from `src` while a copy of it is in flight, or a file that vanishes and reappears (editor save-by-rename), can be deleted in `dst` and then recreated. Define delete as "absent for N consecutive scans" or check against the journal before removing.

**Decisions to change first:**

- Hold the lock for the daemon's lifetime (item 1).
- Add a max-wait cap to the debounce (item 2).
- Use ns mtime + size + inode/ctime; hash only on ambiguity (item 3).
- Copy to temp + atomic rename in `dst` (item 4).
- Pick one definition of "synced" and make the journal follow it (item 5).
- Specify journal fsync and compaction before implementing replay (item 8).
- Replace the scan-cost claim with a measured benchmark on cold cache (item 6).

The polling choice itself is reasonable at this scale. The rejected-alternatives section is weak on the manifest case, but that is secondary to the points above.
