## Baseline findings (read-only)

- `sync()` is `sync(src_root, dst_root, dry_run=False)` → returns `list[str]` (`synccli.py:72`). `main()` is its only caller (`synccli.py:96`); `incremental.py:5` imports only `copy_file`.
- `--dry-run` already yields the would-be-copied list (`synccli.py:81`), so JSON+dry-run needs no new copy logic.
- `skipped` has no current source: `sync()` returns only `copied`, and the total src count lives inside `build_manifest()`.
- **Baseline suite is not green**: `test_first_item_stale_is_included` fails (`test_synccli.py:24`) due to `range(1, ...)` in `collect_stale` (`synccli.py:55`) — pre-existing, unrelated to GOAL, but it blocks any "all tests pass" acceptance.
- I ran the tests; tracked `__pycache__` changes were reverted. Working tree is clean; nothing was modified.

## Execution plan

**Task 1 — Baseline reconnaissance** · agent: `explore`
- **Objective:** pin the real contract and ambiguities before any edit (callers of `sync()`, return-type usage, stdout/stderr sources, meaning of `skipped`, value shape of `src`/`dst`).
- **Files:** read-only on `synccli.py`, `test_synccli.py`, `incremental.py`, `DESIGN.md`.
- **Risks:** misreading `skipped` (src-side unchanged vs dst-side); missing a hidden `sync()` caller.
- **Acceptance:** written report stating: all call sites, confirmed baseline 5 pass / 1 fail, and proposed definition `skipped = len(src files) − len(copied)` with a note that GOAL does not define it.

**Task 2 — Scope gate on the pre-existing failure** · agent: `impl` (only after user says yes)
- **Objective:** decide whether `collect_stale`'s off-by-one is in or out of this change. Default: out of scope, reported only, because it is unrelated to the JSON goal.
- **Files:** `synccli.py` (only if approved), `test_synccli.py` (unchanged — its test already encodes the intended behavior).
- **Risks:** silently fixing unrelated code violates scope discipline; leaving it means "green suite" cannot be an acceptance criterion.
- **Acceptance:** explicit user decision recorded; if approved, `test_first_item_stale_is_included` passes and no other test changes.

**Task 3 — Design decision (design gate)** · agent: `design-review`
- **Objective:** ratify the plumbing that avoids touching `sync()`'s signature/return type. Preferred design: add internal `sync_stats(src, dst, dry_run)` returning `{copied, skipped, src, dst}`; `sync()` becomes a thin delegator that still returns the list; `main()` consumes stats when `--json`. Rejected: rescanning src in `main()` (extra I/O, race) and changing `sync()` to return a dict (breaks signature/return contract).
- **Files:** none (design note in PR/description only).
- **Risks:** reviewer may object to an extra helper; must explicitly freeze `sync()` params and return type.
- **Acceptance:** approved design specifying exact diff surface, JSON key computation, raw-argv `src`/`dst` values, and "all diagnostics → stderr".

**Task 4 — Implement stats helper + delegate `sync()`** · agent: `impl`
- **Objective:** add `sync_stats()`; make `sync()` call it and return `stats["copied"]`; no behavior change, no signature change, dry-run still writes no manifest and copies nothing.
- **Files:** `synccli.py`.
- **Risks:** accidental return-type change; reordering the manifest write; computing `skipped` after copy instead of from the pre-copy manifests.
- **Acceptance:** `inspect.signature(sync)` unchanged; `TestSync` + `TestScanFiles` still pass; `sync_stats()` returns the four expected values on first sync, no-op resync, and dry-run.

**Task 5 — Implement `--json` in `main()`** · agent: `impl`
- **Objective:** add `--json`; when set, emit exactly one `json.dumps` object on stdout with keys `copied`, `skipped`, `src`, `dst`; otherwise keep one path per line; exit code stays `0`.
- **Files:** `synccli.py`.
- **Risks:** stray output corrupting JSON (argparse already writes usage/errors to stderr); double printing the human list; `skipped` diverging between dry-run and real run.
- **Acceptance:** captured stdout for `main([src, dst, "--json"])` parses to exactly that key set with nothing else on stdout; `--json --dry-run` returns the would-be list and creates no files; human-mode output is byte-identical to current behavior.

**Task 6 — Add JSON-shape tests** · agent: `impl`
- **Objective:** in `test_synccli.py`, cover: stdout is valid JSON, exactly the four keys, `copied` matches files, `skipped` count on resync, dry-run lists would-copy without creating files, human mode still one path per line, exit code unchanged.
- **Files:** `test_synccli.py`.
- **Risks:** tests bound to internals rather than CLI behavior; stdout capture leakage; tempdirs not isolated.
- **Acceptance:** tests use `contextlib.redirect_stdout` + `json.loads`; the JSON tests pass; failures are attributable to the new flag only.

**Task 7 — Independent review** · agent: `review`
- **Objective:** review the full diff against GOAL: stdout purity, key completeness, dry-run semantics, unchanged human mode, unchanged exit code, stable `sync()` signature, stdlib-only.
- **Files:** `synccli.py`, `test_synccli.py`.
- **Risks:** missed edge cases (empty src, missing dst, malformed/absent manifest, non-ASCII paths); review may surface the `incremental.py` mutable-default issue — must be classified out-of-scope, not silently fixed.
- **Acceptance:** verdict with findings split minor/major; zero unresolved majors; any major escalates per pipeline (never silently patched by the reviewer).

**Task 8 — Final verification** · agent: `review` (escalate only on major)
- **Objective:** run `python3 -m unittest -v` and the CLI smoke checks (`--json`, `--json --dry-run`, human mode) and confirm acceptance from Tasks 4–6.
- **Files:** none.
- **Risks:** pre-existing failure masks new regressions if not tracked separately (compare test names, not just exit code).
- **Acceptance:** every GOAL-relevant test passes; the only failure, if Task 2 is declined, is the pre-existing `test_first_item_stale_is_included`, explicitly named; human-mode stdout byte-identical pre/post.

**Open decisions needing your call:** (1) define `skipped` as src-side unchanged count — confirm; (2) fix the pre-existing `collect_stale` failure (Task 2) or leave it; (3) whether to document `--json` in README (not required by GOAL).
