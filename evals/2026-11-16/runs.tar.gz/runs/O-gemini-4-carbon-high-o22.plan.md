# Execution Plan: `synccli` `--json` Output Mode + `--dry-run` UX

**Orchestration & Escalation Policy:** Because this repo has no project-local `.opencode/agent/` definitions, tasks route to the global fallback pipeline agents (`explore`, `cheap-design-review`, `cheap-code`, `cheap-review`). Per cost-guard rules, no `strong-*` rung is pre-booked; escalation (`strong-code` / `strong-review`, after notifying the user) occurs only on a demonstrated stall (2–3 failed attempts) or a `major` review finding.

---

### Task 1 — Baseline & Call-Site Exploration
- **Objective:** Inspect `synccli.py`, `incremental.py`, `test_synccli.py`, `GOAL.md`, and `README.md` to map all callers and return-type expectations of `sync(src_root, dst_root, dry_run=False)`, document current CLI stdout/stderr and exit-code behavior in `main()`, and capture baseline `python3 -m unittest -v` results.
- **Files to create/modify:** None (read-only).
- **Pipeline agent:** `explore` (concrete agent: `explore`).
- **Risks:**
  - Undocumented assumptions by internal callers on `sync()` returning `list[str]` (not only its parameter list).
  - Pre-existing unrelated test failure in baseline (`collect_stale` off-by-one at `synccli.py:55` failing `TestCollectStale.test_first_item_stale_is_included`), which could obscure new test results or tempt out-of-scope fixes without user approval.
- **Verifiable acceptance criterion:** Exploration report returned to orchestrator containing: (1) all repo references to `sync()` and `copy_file()`, (2) confirmation of `sync(src_root, dst_root, dry_run=False) -> list[str]` contract, and (3) exact output of `python3 -m unittest -v` isolating pre-existing failures from `TestSync`.

---

### Task 2 — JSON Contract & Internal Factoring Design Review
- **Objective:** Audit the implementation approach before coding: keep `sync(src_root, dst_root, dry_run=False) -> list[str]` unchanged by extracting a single-pass internal helper (e.g., `_sync_with_stats`) returning `(copied, skipped)` where `skipped = len(src_manifest) - len(to_copy)`, preserving `args.src` and `args.dst` verbatim in `{"copied": [...], "skipped": N, "src": ..., "dst": ...}`, guaranteeing stdout contains only that single JSON object under `--json` (including with `--dry-run`), and keeping exit codes unchanged.
- **Files to create/modify:** None (read-only critique of the orchestrator's contract brief).
- **Pipeline agent:** `design-review` (concrete agent: `cheap-design-review`).
- **Risks:**
  - Computing `skipped` via a second `build_manifest()` scan in `main()` would cause double filesystem `stat` I/O and a TOCTOU mismatch between `copied` and `skipped`.
  - Changing `sync()`'s return value (e.g., returning a dict/tuple) would break existing callers (`TestSync` and internal callers).
  - Ambiguity on edge cases: empty source tree (`copied: []`, `skipped: 0`), `--dry-run` non-mutation of `.sync_manifest.json`, and `copy_file()` silent `OSError` handling.
- **Verifiable acceptance criterion:** `cheap-design-review` issues an explicit sign-off (zero unresolved architectural blockers) confirming `sync()` signature/return compatibility, single-pass `skipped` computation, `--dry-run` + `--json` semantics, and Python 3.10 stdlib-only compliance.

---

### Task 3 — Implement `--json` Flag and `--dry-run` Interplay
- **Objective:** Update `synccli.py` to add `--json` to `argparse` in `main()`, factor single-pass stats calculation so `sync(src_root, dst_root, dry_run=False)` delegates to it without changing signature or return value, emit a single JSON object `{"copied": copied, "skipped": skipped, "src": args.src, "dst": args.dst}` to stdout when `--json` is passed (with `copied` listing what *would* be copied when combined with `--dry-run`), preserve human mode (one path per line), and preserve exit code `0`.
- **Files to create/modify:** Modify `synccli.py`.
- **Pipeline agent:** `impl` (concrete agent: `cheap-code`).
- **Risks:**
  - Stray stdout output (human-mode lines or warnings) emitted alongside the JSON payload, violating the single-JSON-object stdout requirement.
  - Writing files to `dst` or updating `.sync_manifest.json` when `--dry-run` and `--json` are used together.
  - Introducing non-stdlib imports or Python >3.10 constructs.
- **Verifiable acceptance criterion:**
  - `inspect.signature(synccli.sync)` is `(src_root, dst_root, dry_run=False)` and `synccli.sync(...)` returns `list[str]`.
  - Running `python3 -m synccli <src> <dst> --json` and `python3 -m synccli <src> <dst> --dry-run --json` exits `0` and emits stdout that `json.loads()` parses into a single `dict` with exact keys `{"copied", "skipped", "src", "dst"}`.
  - Running without `--json` continues to print one relative path per line and exit `0`.

---

### Task 4 — Add Unit Tests for JSON Shape, Dry-Run Semantics, and Compatibility
- **Objective:** Add unit test cases to `test_synccli.py` covering `--json` output validity (`json.loads` on full captured stdout), exact required keys and value types (`copied`, `skipped`, `src`, `dst`), `skipped` count on repeat/partial syncs, `--json --dry-run` interplay (`copied` lists prospective copies while `dst` files and `.sync_manifest.json` remain untouched), human-mode output preservation, exit code `0`, and `sync()` signature/return stability.
- **Files to create/modify:** Modify `test_synccli.py`.
- **Pipeline agent:** `impl` (concrete agent: `cheap-code`, resuming Task 3 `task_id` while well under the 100K context cap).
- **Risks:**
  - Asserting partial stdout substrings instead of `json.loads()` over the entire captured stdout buffer, failing to catch extra output lines.
  - Omitting filesystem assertions verifying `--dry-run --json` writes neither destination files nor `.sync_manifest.json`.
  - Modifying out-of-scope `TestCollectStale` / `collect_stale` without explicit user permission.
- **Verifiable acceptance criterion:** `python3 -m unittest test_synccli.TestSync` and the new JSON/CLI `TestCase` class(es) in `test_synccli.py` pass 100% (`exit 0`), testing initial sync, repeat/incremental `skipped` counts, empty directory, `--dry-run --json`, and human mode.

---

### Task 5 — Cross-Lineage Implementation & Test Review
- **Objective:** Review the full `git diff` across `synccli.py` and `test_synccli.py` against every constraint in `GOAL.md` and `README.md`; route any `minor` findings back to the `cheap-code` `task_id` followed by a fresh `cheap-review` pass, or report to the user before escalating any `major` finding.
- **Files to create/modify:** None (read-only).
- **Pipeline agent:** `review` (concrete agent: `cheap-review`, fresh session).
- **Risks:**
  - Overlooked edge cases in nested relative path formatting, Unicode filenames in `json.dumps`, or CLI argument order (`--json --dry-run` vs `--dry-run --json`).
  - Unintended modifications outside `synccli.py` and `test_synccli.py`.
- **Verifiable acceptance criterion:** `cheap-review` reports zero unresolved `major` or `minor` findings; `git diff --name-only` lists only `synccli.py` and `test_synccli.py`; zero third-party dependencies are present; all `TestSync` and new `--json`/`--dry-run` unit tests pass under Python 3.10+.
