Read `GOAL.md`, `README.md`, plus the surrounding code (`synccli.py`, `incremental.py`, `test_synccli.py`, `DESIGN.md`) to ground the plan. No files were modified.

## Scope note

`DESIGN.md` (the `syncd` daemon) is **out of scope** for GOAL.md — it is a separate future release. `incremental.py` is "commit under review" and unrelated to the JSON/dry-run feature; it must not be touched except to keep `copy_file` importable. Its latent bugs (`collect_stale` drops `items[0]`; `filter_excluded` mutable default arg) are flagged, not fixed.

---

## Task 1 — Reconnaissance
- **Objective:** confirm the full call graph of `sync()`, `copy_file`, and `main()`; enumerate every consumer of the public surface so the "signature stable" constraint is provably honored.
- **Files:** read-only — `synccli.py`, `incremental.py`, `test_synccli.py`, `DESIGN.md`, `GOAL.md`.
- **Agent:** `explore`
- **Risks:** a hidden consumer of `copy_file`'s return value (`incremental.py:18` `copy_many` ignores it) makes "make `copy_file` report success" a breaking change; discover this *before* design, not after.
- **Acceptance:** a written list of every in-repo caller of `sync()`, `copy_file()`, `copy_many()`, and the current return-value contracts, with file:line.

## Task 2 — Design: resolve the spec's ambiguities
- **Objective:** write a short design that pins down the four under-specified points, since the JSON schema is a machine-facing contract:
  1. **`skipped` semantics** — GOAL.md gives a count with no definition. Decide: skipped = source files *not* copied (manifest files minus copied) vs. copy *failures*. Recommended: skipped = number of files in the source manifest that were not copied (i.e. failed reads/copies), and `copied` lists only files actually written.
  2. **Failure visibility** — `copy_file` currently swallows `OSError` (`synccli.py:67`), so a failure is currently indistinguishable from a success. Decide whether to (a) change `copy_file` to return a bool (backwards-compatible: current callers ignore the value) or (b) re-stat after copy in `sync()`. Option (a) is preferred — but the *retained* `copy_file` name and `synccli.copy_file` importability must be preserved for `incremental.py`.
  3. **`src` / `dst` values** — as-given on the command line vs. absolute. Recommend as-given (what the user typed), because absolute paths leak the local filesystem into machine output; must be documented.
  4. **Where JSON is emitted** — in `main()` only, never inside `sync()`; `sync()` keeps returning the plain list of relative paths so its signature and return type are unchanged.
- **Files:** create `docs/json-mode-design.md` (new; the only new file).
- **Agent:** `cheap-design`, then **`cheap-design-review`** (`cheap-design-review`)
- **Risks:** choosing the wrong `skipped` definition ships a wrong machine contract that consumers bake in; changing `sync()`'s return type breaks the constraint outright; re-statting after copy introduces a TOCTOU race and is slower — prefer the bool return.
- **Acceptance:** the design doc fixes all four points, states the exact JSON schema with a literal example object, and shows the `sync()` signature byte-identical to today's `sync(src_root, dst_root, dry_run=False)` returning `list[str]`.

## Task 3 — Implementation: `--json` and `--dry-run` in `synccli.py`
- **Objective:** add `--json` to the argparse parser; in JSON mode print exactly one `json.dumps` object to stdout with keys `copied` (list of relative paths), `skipped` (int), `src`, `dst`; in human mode keep one path per line, unchanged.
- **Files:** modify `synccli.py` — `copy_file` (return success bool, per Task 2), `sync` (collect skipped count; **keep the signature and the list return type stable**), `main` (add `--json` flag, branch on output mode; exit code stays `0`).
- **Agent:** `cheap-code` (impl)
- **Risks:**
  - stdout purity — the *only* stdout write in JSON mode must be the single JSON object; any stray `print()` breaks "nothing else may be printed". `sync()` currently prints nothing, so the branch must be exhaustive.
  - `--dry-run` + `--json`: `copied` must list *would-be* copies. Note that `sync()`'s dry-run path (`synccli.py:81`) returns early **before** writing the manifest — dry-run must also not write the manifest and must not touch `dst`.
  - `skipped` in dry-run must be consistent with the non-dry-run definition (files that would not be copied).
  - The JSON object must be emitted even when `copied` is empty (`{"copied": [], "skipped": 0, ...}`), not `null`.
  - `incremental.py:5` imports `copy_file` from `synccli` — the name must remain importable with the same arity.
  - JSON output must be a single line/one object; use `json.dumps(obj)` with no extra `print` of the object plus a separate newline.
- **Acceptance:** `python3 -m synccli SRC DST --json` prints stdout that is exactly one parseable JSON object with all four keys, and nothing else on stdout; `python3 -m synccli SRC DST` prints the same paths one per line as before; `python3 -m synccli SRC DST --json --dry-run` lists would-be copies and leaves `dst` unchanged (no `.sync_manifest.json` created); exit code is `0` in all three cases.

## Task 4 — Implementation: unit tests
- **Objective:** add tests to `test_synccli.py` covering the JSON shape and dry-run semantics.
- **Files:** modify `test_synccli.py` — new test class (e.g. `TestJsonMode`) using `contextlib.redirect_stdout` and `json.loads` on the captured stdout.
- **Agent:** `cheap-code` (impl) — same session as Task 3 if the context is still fresh, otherwise a fresh briefed session
- **Risks:** capturing stdout only (not stderr) is what proves the "nothing else on stdout" requirement — a test that also captures stderr would not catch a stray print; a test that asserts `json.loads(stdout)` succeeds implicitly proves stdout purity, so don't strip or filter the captured text. Must not depend on the machine's `os.sep` for expected paths — build expectations with `os.path.join`.
- **Acceptance:** new tests exist and pass, asserting (a) stdout parses as a single JSON object, (b) the four keys are present, (c) `copied` equals the expected relative paths, (d) `skipped` is the expected int, (e) with `--dry-run` the JSON `copied` lists would-be copies while `dst` is untouched, (f) human mode still prints one path per line.

## Task 5 — Review
- **Objective:** adversarial review of the Task 3 + 4 diff.
- **Files:** read-only review of `synccli.py`, `test_synccli.py`, `incremental.py` (unchanged).
- **Agent:** `cheap-review` (review)
- **Risks:** a reviewer that skips `incremental.py` will miss a broken `copy_file` import; ask explicitly for that check. A review that doesn't re-run the test suite accepts untested claims — require the reviewer to run `python3 -m unittest -v`.
- **Acceptance:** the reviewer returns either "no findings" or findings classified minor/major, with a run of `python3 -m unittest -v` showing all tests green; every minor finding is fixed by the same `cheap-code` session before Task 6.

## Task 6 — Verification
- **Objective:** final acceptance run against GOAL.md's four numbered requirements.
- **Files:** none (read-only execution).
- **Agent:** `cheap-code` or `explore` (execution only) — escalate to `strong-review` if Task 5 produced a major finding that was not cleanly resolved.
- **Risks:** a green suite that never exercised the CLI entry point; the CLI path must be verified by invoking `python3 -m synccli` as a subprocess, not only by calling `main()` in-process.
- **Acceptance:** `python3 -m unittest -v` fully green; a subprocess run with `--json` yields stdout that `json.loads` accepts as one object with exactly the keys `copied`, `skipped`, `src`, `dst`; a human-mode run is byte-identical to pre-change behavior on the same fixture; `--dry-run --json` writes nothing into `dst`; no new imports beyond the stdlib (verify by diffing the import block of `synccli.py`).

---

**Escalation policy:** Tasks 3–4 go to `cheap-code` first (cost is negligible); only a demonstrated stall (2 consecutive failed attempts) or a major `cheap-review` finding escalates to `strong-code` / `strong-review`. Task 2 is the only genuine design decision; it must be settled before Task 3 starts, since `skipped` semantics and the `copy_file` return-value change are baked into the JSON contract that consumers depend on.
