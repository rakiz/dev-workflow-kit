# Execution plan: `--json` mode and dry-run UX

I read GOAL.md, README.md and the three Python files (`synccli.py`, `incremental.py`, `test_synccli.py`). I changed nothing.

## Findings that shape the plan

- **`main()`** (`synccli.py:90-99`) only prints one path per line. It has no `--json` flag and always returns 0.
- **`sync()`** returns `to_copy` only. `skipped` is not available, but it can be derived as `len(src_manifest) - len(to_copy)`. The `sync()` signature must stay stable, so I won't change it or its return value.
- **`copy_file()`** (`synccli.py:68-69`) swallows `OSError`. A file that failed to copy is still reported in `copied` and still written to the manifest. This is an existing correctness risk, because `copied` in JSON would be misleading. It is out of scope unless you approve it (see the questions at the end).
- **Existing suspected bugs:**
  - `collect_stale` skips item 0 (`range(1, …)`). `test_first_item_stale_is_included` probably fails today.
  - `filter_excluded` has a mutable default argument.
  - `copy_many` can never see an error from `copy_file`.
  - These are unrelated to the goal, so they are not in the plan.
- **stdout purity:** in `--json` mode nothing else may reach stdout. The current code prints nothing else, but argparse errors and any future `print` call must be kept off stdout.
- **Skipped definition:** GOAL.md leaves `skipped` unspecified. I will define it as the number of source files not copied.

## Tasks

### T1. Baseline and reconnaissance
- **Agent:** `explore`
- **Objective:** Run `python3 -m unittest -v` to record the baseline. Confirm which tests already fail (expected: `collect_stale`). Grep for internal callers of `sync()` and `main()`. Confirm that `incremental.py` is not used by the CLI path.
- **Files:** none (read-only).
- **Risks:** Pre-existing failures could be mistaken for regressions.
- **Acceptance:** A written list of baseline pass/fail tests and the callers of `sync()`. This list is the reference for later tasks.

### T2. Design note (small, no separate doc)
- **Agent:** `design-review`, as a quick review of the decisions below before coding. This stays cheap; I'm not escalating.
- **Objective:** Validate these decisions:
  1. `main()` builds `{"copied": copied, "skipped": N, "src": args.src, "dst": args.dst}` and calls `json.dumps` once, with `print` as the only stdout write.
  2. `skipped` is computed without changing the `sync()` signature or return type. Options: a new private helper that `sync()` delegates to (it keeps returning a list), or `main()` calling `build_manifest(src)` again. Preferred option: an internal `_sync_impl` returning `(to_copy, total)`, with `sync()` as a thin wrapper.
  3. In dry-run mode, `copied` lists `to_copy` and nothing is written.
  4. Human mode is untouched.
  5. A possible `OSError` from `sync()` itself is not caught.
- **Files:** none.
- **Risks:** Re-scanning the source twice causes inconsistency or double I/O. Choosing an option that changes the `sync()` contract is also a risk.
- **Acceptance:** The reviewer confirms that `sync()`'s signature and return value are unchanged and that `skipped` is unambiguous.

### T3. Implement `--json` in `synccli.py`
- **Agent:** `impl` (cheap-code)
- **Objective:** Add `--json` (`action="store_true"`) and the JSON output path. Keep human mode byte-identical. Add the skipped computation per T2. Exit code stays 0.
- **Files to modify:** `synccli.py` (the `main()` and `sync()` area only).
- **Risks:**
  - `sync()`'s signature or return value changes by accident.
  - A stray `print` ends up on stdout.
  - Paths contain non-ASCII characters (use `json.dumps` defaults, or an explicit `ensure_ascii`).
  - `copied` contains `os.sep` paths, which differ on Windows. Document this and don't normalise.
  - `--json` combined with `--dry-run` must write nothing to disk.
- **Acceptance:**
  - `python3 -m synccli SRC DST --json | python3 -c "import json,sys; d=json.load(sys.stdin); assert set(d)=={'copied','skipped','src','dst'}"` passes.
  - Without `--json`, the output for the same inputs is identical to before.
  - `git diff` shows the `sync()` signature line unchanged.

### T4. Unit tests in `test_synccli.py`
- **Agent:** `impl` (cheap-code, same instance as T3 if it is still small; otherwise fresh with a full brief)
- **Objective:** Add tests that call `main([...])` with captured stdout (`contextlib.redirect_stdout`) and a tempdir. Cases:
  - **Valid JSON:** `json.loads(stdout)` succeeds and stdout holds a single object (exactly one trailing newline).
  - **Keys and types:** the four keys are present, `copied` is a list, `skipped` is an int, and `src` and `dst` match the arguments.
  - **Dry-run semantics:** with `--json --dry-run`, `copied` lists the would-be files and the destination has no copied file and no manifest.
  - **Skipped count:** after a first sync, a second run gives `copied == []` and `skipped == N`.
  - **Exit code:** it is 0.
  - **Human mode:** one path per line, with no JSON.
- **Files to modify:** `test_synccli.py` (new test class; existing tests stay untouched).
- **Risks:**
  - The tests depend on the `sync()` stdout and manifest behaviour.
  - A test that silently passes (for example one that never checks stdout).
  - Temp dirs are not cleaned up.
- **Acceptance:** `python3 -m unittest -v` shows the new tests passing. The only failing tests are the baseline failures recorded in T1 (no new failures). Temporarily breaking the implementation (for example adding a `print`) makes at least one new test fail. The reviewer in T5 does this check by reading.

### T5. Review
- **Agent:** `review` (cheap-review, a fresh instance with a self-contained brief that includes the `git diff`)
- **Objective:** Check the diff against each GOAL.md constraint:
  - A single JSON object on stdout, and nothing else.
  - Exit code unchanged.
  - Human mode unchanged.
  - `sync()` signature stable.
  - No new dependencies, and Python 3.10 stdlib only (no `match`-style code beyond 3.10, no `tomllib`).
  - Test quality.
- **Files:** read-only.
- **Risks:** The reviewer misses existing bugs or flags unrelated ones as in scope.
- **Acceptance:** A verdict of "no major findings". Minor findings are fixed by resuming the T3/T4 instance through `task_id`. A major finding is escalated to strong-code.

### T6. Final verification
- **Agent:** `explore` (read-only runner)
- **Objective:** Run the full test suite and manual smoke tests for human mode, `--json`, and `--json --dry-run` in a tempdir. Check that `git status` shows only `synccli.py` and `test_synccli.py` changed, and that README.md (usage examples for the new flag, an optional one-line addition) is untouched unless you approve it.
- **Files:** none.
- **Risks:** Environment differences (Python version). Check with `python3 --version` that it is 3.10 or newer.
- **Acceptance:** All new tests pass. Every baseline-failing test is unchanged. The smoke-test output matches the GOAL.md shape. The diff touches no file other than `synccli.py` and `test_synccli.py`.

## Questions for you
These need an explicit yes before I act on them:
1. Should I fix the unrelated bugs (`collect_stale` off-by-one, the mutable default in `filter_excluded`, the swallowed `OSError` in `copy_file`)? The swallowed error can make `copied` misleading in JSON mode.
2. Do you accept the definition `skipped = number of source files not copied`?
3. Should I add a short `--json` usage line to README.md?
