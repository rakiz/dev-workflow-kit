# Execution plan

**Scope:** Modify only `synccli.py` and `test_synccli.py`; no new files or dependencies are planned. `incremental.py` must be inspected for internal-call compatibility. `README.md` already delegates usage to `--help`, so no documentation change is required.

## 1. Map current behavior and establish the baseline

- **Agent:** `explore`
- **Objective:** Trace argument parsing, `sync()`, dry-run handling, copied/skipped accounting, stdout/stderr writes, and exit-code paths. Identify existing test helpers and internal callers, including `incremental.py`. Run the current test suite.
- **Files to create/modify:** None. Read `synccli.py`, `test_synccli.py`, and `incremental.py`.
- **Risks:**
  - Output may be emitted inside reusable functions rather than only at the CLI boundary.
  - Internal callers may depend on `sync()`’s exact signature or current result.
  - Dry-run accounting may differ from actual-copy accounting.
- **Acceptance criterion:** A read-only report identifies the current `sync()` signature, all output sites, dry-run control flow, exit paths, and relevant tests. Baseline `python3 -m unittest -v` results are recorded.

## 2. Review the minimal integration design

- **Agent:** `design-review`
- **Objective:** Review a design that adds `--json` and `--dry-run` at the CLI boundary, reuses the existing synchronization decision path, and separates machine-readable rendering from human rendering without changing `sync()`’s signature.
- **Files to create/modify:** None.
- **Risks:**
  - Duplicating copy-selection logic could make dry-run results disagree with real runs.
  - Refactoring `sync()`’s interface could break internal callers.
  - Incidental messages could contaminate JSON stdout.
  - Serializing paths or counts without normalization could produce invalid JSON or incorrect types.
- **Acceptance criterion:** The reviewed design explicitly covers both flags, the exact top-level keys `copied`, `skipped`, `src`, and `dst`, stdout/stderr separation, unchanged exit-code propagation, human-mode compatibility, stable `sync()` signature, and tests for normal, dry-run, human, and failure paths.

## 3. Implement JSON output and its unit tests

- **Agent:** `impl`
- **Objective:** Add the CLI behavior and extend `test_synccli.py` using only Python 3.10 stdlib facilities.
- **Files to create/modify:**
  - Modify `synccli.py`.
  - Modify `test_synccli.py`.
  - Create no files.
- **Required behavior:**
  - JSON mode emits exactly one valid JSON object to stdout and nothing else there.
  - `copied` is a list, `skipped` is an integer, and `src`/`dst` identify the requested source and destination.
  - With `--json --dry-run`, `copied` contains the paths that would be copied and no copy occurs.
  - Human output remains one path per line.
  - Exit codes and `sync()`’s signature remain unchanged.
- **Risks:** Regressions in ordinary human output, dry-run side effects, incorrect skipped counts, or error output leaking to stdout.
- **Acceptance criterion:** New tests parse stdout with `json.loads`, assert the required keys and value types, verify dryrun filesystem semantics, and preserve existing human-mode expectations. `python3 -m unittest -v` completes successfully.

## 4. Review implementation and test quality

- **Agent:** `review`
- **Objective:** Review the complete diff against `GOAL.md`, inspect for compatibility and output-channel violations, and independently run the tests.
- **Files to create/modify:** None.
- **Risks:**
  - Tests may check JSON parsing but miss extra stdout, missing keys, exit-code changes, or dry-run side effects.
  - The implementation may pass new tests while breaking existing internal callers or human output.
- **Acceptance criterion:** The reviewer verifies every goal and constraint against concrete code/tests and reports no unresolved correctness finding. `python3 -m unittest -v` passes independently.

## 5. Correct any review findings

- **Agent:** `impl` — resume the implementation instance if the findings concern the same small change; otherwise skip this task when review is clean.
- **Objective:** Apply only fixes required by verified review findings and add regression coverage where needed.
- **Files to create/modify:** Only `synccli.py` and/or `test_synccli.py`.
- **Risks:** Fixes could introduce unrelated refactoring or regress another output mode.
- **Acceptance criterion:** Every finding is resolved by a corresponding code/test change, and the complete test suite passes again. Skip entirely if Task 4 found no issue.

## 6. Final acceptance verification

- **Agent:** `review` — a fresh reviewer after any Task 5 changes.
- **Objective:** Perform the final read-only audit and acceptance run.
- **Files to create/modify:** None.
- **Risks:** Post-review fixes may invalidate earlier verification.
- **Acceptance criterion:** All tests pass with exit status 0; JSON, combined dry-run, unchanged human output, unchanged exit codes, stdlib-only compatibility, and the stable `sync()` signature are all explicitly confirmed. No unresolved review findings remain.

**No repository modifications were made.**
