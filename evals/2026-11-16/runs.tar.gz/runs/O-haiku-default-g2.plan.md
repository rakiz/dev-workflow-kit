I read GOAL.md, README.md, and the three Python files (`synccli.py`, `incremental.py`, `test_synccli.py`) to ground the plan. No files were modified.

## Findings that shape the plan

- **Baseline test failure (needs a decision first):** `collect_stale` iterates `range(1, len(items))`, so it skips `items[0]`. `test_first_item_stale_is_included` expects `["x.txt", "y.txt"]` but gets `["y.txt"]`, so the suite is likely red before any change. The task's acceptance "all tests green" is unreachable without touching `collect_stale`, which is out of scope. The baseline task must confirm this.
- **`sync()` cannot report skipped:** it returns only `to_copy`. To keep its signature, the skipped count needs an internal helper that `sync()` wraps, or a count derived in `main()`.
- **Silent failures:** `copy_file` swallows `OSError`, so `copied` can list files that were never written. `sync()` also writes the manifest regardless. Human mode has the same behavior, so JSON should match it, and this should be flagged rather than fixed.
- **`skipped` is undefined in GOAL.md:** I assume `skipped = (number of src files) - len(copied)`. Dot-directories excluded by `scan_files` are not counted.
- **Other pre-existing issues, out of scope:** `filter_excluded` has a mutable default argument, and `incremental.py` has no tests.

## Execution plan

**T0. Baseline verification**
- Objective: record the test state and confirm callers of `sync()` before changing anything.
- Files: none (read-only).
- Agent: `explore`.
- Steps: run `python3 -m unittest -v`; grep for `sync(` callers across the repo; confirm the `collect_stale` failure.
- Risks: if the failure is confirmed, the suite cannot be fully green without a separate, approved fix.
- Acceptance: a written baseline listing pass/fail per test and every `sync(` call site. Gate: the user decides whether `collect_stale` is fixed separately or the acceptance is scoped to the new tests.

**T1. Design decision: skipped count (optional, small)**
- Objective: choose how `skipped` is computed without changing `sync()`'s signature or return type.
- Options: (A) `main()` calls `build_manifest` again to count, which double-scans and can race. (B) an internal `_sync(src, dst, dry_run)` returns `(copied, skipped)`, and `sync()` returns only `copied`. Option B is recommended.
- Files: none; design note only.
- Agent: `cheap-design-review` on a short design note from `cheap-design` (or the orchestrator's own note). Skip it if you accept option B directly.
- Risks: a reviewer may over-engineer. Keep the note to under a page.
- Acceptance: one option chosen with rationale; `sync()` signature unchanged.

**T2. Implement `--json` in `synccli.py`**
- Objective: add `--json` to `main()`. In JSON mode, print exactly one `json.dumps` object `{"copied": [...], "skipped": N, "src": argv_src, "dst": argv_dst}` to stdout. Human mode prints one path per line as before. Exit code stays 0.
- Files to modify: `synccli.py` (`main`, plus the helper from T1). Do not change the `sync()` signature.
- Agent: `cheap-code`, then `cheap-review`.
- Dependencies: T0, T1.
- Risks: any stray print or warning on stdout breaks JSON purity; `--dry-run` must not write the manifest; `copied` must be a list of strings, not a set.
- Acceptance: `python3 -m synccli SRC DST --json | python3 -m json.tool` succeeds on an empty and a non-empty source; stdout contains only that object; `python3 -m synccli SRC DST` output is byte-identical to before.

**T3. Dry-run + JSON semantics**
- Objective: with `--json --dry-run`, `copied` lists the would-copy files, and nothing is written to DST (no files, no manifest).
- Files to modify: `synccli.py` only if T2 left a gap.
- Agent: `cheap-code`, then `cheap-review`.
- Dependencies: T2.
- Risks: a naive implementation could call `copy_file` in dry-run.
- Acceptance: after the dry run, DST contains no new files and no `.sync_manifest.json`; `copied` equals the list a non-dry run would produce.

**T4. Unit tests in `test_synccli.py`**
- Objective: add a test class covering JSON shape (valid JSON, keys `copied`/`skipped`/`src`/`dst` present, types correct), dry-run semantics, and human-mode unchanged. Capture stdout with `contextlib.redirect_stdout` and call `main([...])`.
- Files to modify: `test_synccli.py` (append only; do not edit existing tests).
- Agent: `cheap-code`, then `cheap-review`.
- Dependencies: T2, T3.
- Risks: temp directories not cleaned up; tests that rely on mtime ordering can be flaky.
- Acceptance: the new tests pass when run with `python3 -m unittest -v test_synccli.TestJson...`; the new tests fail if `--json` is removed (verify this mutation manually).

**T5. Review of the full diff**
- Objective: check the diff against GOAL.md constraints: stdlib only, Python 3.10 compatible, `sync()` signature stable, stdout purity, exit code unchanged, no unrelated edits.
- Files: none (review only).
- Agent: `cheap-review` as a fresh reviewer. Escalate any major finding to `strong-review`.
- Dependencies: T4.
- Acceptance: no major findings, or all major findings are resolved and re-reviewed.

**T6. Final verification**
- Objective: run the full suite and the manual JSON checks, and report results.
- Files: none.
- Agent: `explore` (run commands, report output).
- Dependencies: T5.
- Acceptance: new tests pass; the only failures are those recorded in T0 (or none, if the user approved the `collect_stale` fix); manual JSON checks pass.

**Not in the plan (needs your explicit yes):**
- Fixing `collect_stale`'s off-by-one, `filter_excluded`'s mutable default, or the `copy_file` error swallowing.
- Updating README.md. It only documents `--help` and the test command. I would suggest a one-line mention of `--json`, but I have not added it.
- Adding tests for `incremental.py`.

**Decisions needed from you:**
1. Is the `collect_stale` baseline failure to be fixed in a separate change, or should acceptance exclude it?
2. Confirm `skipped = len(src files) - len(copied)`.
3. Should `copied` in JSON mode report only successful copies (requires changing `copy_file` to return a status), or match the current human-mode behavior? I recommend matching human mode and flagging the gap.
