Read it (and `state.py`/`syncd.py` for grounding). Verdict: the approach is sound in shape but several core guarantees it claims are false as written. Change these before writing code.

## Wrong assumptions

1. **"mtime is guaranteed to change on every edit" — false.** `snapshot()` stores `int(st.st_mtime)` (whole seconds). Two same-size edits inside one second are identical `(size, mtime)` → change is silently never copied. Also `cp -p`/`rsync -t`/`tar`/some checkouts preserve mtime; coarse-timestamp filesystems. This is silent staleness, the worst failure mode. Use `st_mtime_ns`+size at minimum; keep a hash option for `--verify`.

2. **"one daemon ever writes to dst" — contradicted by the design itself.** Lock is released before commit *and* before `sleep()` (syncd.py:63-71), so a second instance can acquire it every cycle. Worse: `acquire_lock` is check-then-create (TOCTOU, not atomic) and leaves a stale lockfile after any crash → the daemon can never restart. Decide: hold an `flock` for process lifetime, or `O_CREAT|O_EXCL`, with stale-PID handling. Delete the "commit needs no lock / entries merge cleanly" paragraph — it's rationalizing a bug.

3. **"latency stays under one poll + 200 ms even while a file is being written continuously" — false.** The quiet period restarts on every observed change, so a continuously-written file (append log, active build artifact) never reaches 200 ms quiet and is never flushed while it's being written. Unbounded latency. Add a max-age/deadline flush independent of quiet.

4. **"pending bounded by one poll's worth; memory flat" — false.** Cycle time = scan + copy + commit + sleep, so under a burst copies delay the next scan and `pending` grows beyond one poll. And deletions never prune `pending`/`quiet_since`/`observed`/`synced` — long-running daemon leaks per deleted file.

5. **"crash loses nothing" — only partly true.** (a) dst writes are in-place (`open(dst,"w")` truncates first), so a crash mid-copy destroys the previously-good dst file; manifest still says synced → never re-copied. Need tmp+rename for dst writes (you rejected tmp+rename only for the *manifest* — dst needs it more). (b) journal isn't fsynced, so "loses nothing" is not guaranteed. (c) manifest is rewritten in place with no `try/except` in `load_manifest` — a torn JSON file crashes startup *before* journal replay can "repair" it.

6. **"journal replay repairs everything" — understates startup cost and resurrects deletions.** Journal is append-only, never compacted (GOAL #3), one line per copy forever → replay-before-scan is O(all copies ever), so restart latency degrades without bound over weeks. Deletions are never journaled, so replay re-adds deleted paths each restart. Truncate after an atomic manifest commit.

## Breaks under real load

- **Error containment is assumed, not designed.** `snapshot()`'s `os.stat`, `open(src)`, `os.makedirs`, and dst write all throw on vanished files, EACCES, or ENOSPC — one bad file kills the loop, contradicting "never takes the daemon down." Needs per-file try/except + backoff + logging.
- **Reads whole file into RAM** (syncd.py:47): a multi-GB artifact OOMs the daemon and, being single-threaded, stalls *all* syncs for the copy duration. Stream; consider a small bounded worker pool.
- **Unconditional manifest commit every 500 ms** re-serializes 50k entries even when nothing changed — constant CPU/IO and the write-amplification you were trying to avoid. Commit only when dirty.
- **The "well under 100 ms" scan number is unmeasured** and ignores `json.load` of a 50k-entry manifest each cycle plus cold-cache/network-FS stat costs. Measure before betting the no-watchers decision on it.
- **Hidden paths are a silent scope decision:** dot-directories (`.git`, `.venv`) are excluded but dot-files are copied — inconsistent and undocumented. State it or expose it.

## Change first
Lock (process-lifetime, atomic, stale-safe) → `st_mtime_ns` identity + document manifest compat → atomic dst writes (tmp+rename) → journal truncate after atomic manifest commit → error containment per file → max-age flush for debounce. Those six reorder everything else; the rest is tuning.
