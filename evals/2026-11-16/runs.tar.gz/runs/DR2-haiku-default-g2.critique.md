**Critique of DESIGN.md (syncd v2), before any code**

**Blockers**

1. **Debounce starves continuously-written files.** The quiet period restarts on every observed change, so a file written at least every 200 ms is never copied. The claim that latency stays under "one poll + 200 ms even while a file is being written continuously" is false. Add a max-wait cap (copy at most N seconds after first change).
2. **Single-instance guarantee is broken.** The lock is released before the manifest commit, and the doc says a second instance's entries "merge cleanly." The manifest is a whole-file rewrite, so the second writer's commit overwrites the first's entries (last writer wins). Two daemons can also write `dst` concurrently. Hold the lock through the commit.
3. **Mass deletion on a transient `src` problem.** Reconcile deletes from `dst` whenever a file is missing from `src`. An unmounted volume, an empty walk after a permissions error, or a build tool that deletes and recreates a directory will wipe `dst`. Add a guard: refuse deletes if the root is missing or the scan returns far fewer files than the manifest (e.g. >X% drop), and require the deletion to persist across two scans.
4. **Change detection misses real edits.** mtime is stored at whole-second resolution, so two same-size edits within one second are invisible. The rejection of content hashing rests on "mtime is guaranteed to change on every edit," which is false at this resolution. Use `st_mtime_ns` plus `st_size` and `st_ctime_ns`, and hash only on ambiguity (same stat, recent mtime).
5. **`dst` is never written atomically.** The doc rejects tmp+rename for the manifest but says nothing about `dst`. Readers (compilers, test runners) can see a partial file, and "never ends up holding a truncated copy" is not guaranteed because the re-stat check only catches changes after the copy, not during it. Copy to a temp file in `dst`, fsync, and `rename`.

**Wrong assumptions**

6. **The crash-repair story doesn't hold.** A torn manifest is unreadable, so there is no base to replay the journal onto. Replay needs a known-good base, which means either a write-then-rename manifest or a checkpoint. The journal also has no compaction policy and grows without bound during bursts.
7. **Backpressure bound is asserted, not derived.** "Pending is bounded by one poll's worth" assumes each poll drains everything. If copies take longer than the 500 ms poll, passes overlap or queue, and new changes keep arriving during the drain. Pending is not bounded by a poll interval.
8. **Scan cost is a warm-cache, single-machine number.** "Well under 100 ms" for 50k `stat` calls depends on the OS page cache and excludes Python overhead. Polling at 500 ms is about 100k stats/s continuously, which costs battery on a laptop and is wasteful. Provide the measurement (cold and warm, on the target machine) or design for FSEvents/inotify with polling as a fallback.
9. **Latency arithmetic is inconsistent.** Debounce is checked per poll, so the effective quiet period is quantized to 500–1000 ms, not 200 ms. The constants comment ("exposing them invites configurations where the quiet period exceeds the poll budget") is backwards: the design already has that mismatch.

**Unaddressed under real load**

- Symlinks, permissions and ownership, ignore rules (`.gitignore`, build outputs), and whether `dst` can sit under `src` (recursive copy loop).
- Disk-full or write errors on `dst`: the errors section covers only source-side failures.
- Copy-loop duration on a burst of hundreds of files (sequential copy at 500 ms polls will fall behind; the design only logs it).
- The design reuses `state.py` (`snapshot()`, lockfile, journal) without stating what it guarantees. Read that code before accepting the Crash safety and Single instance sections.

**Decisions to change first**

1. Hold the lock for the whole cycle, including commit (fixes 2).
2. Add the delete guard and two-scan confirmation for deletions (3).
3. Switch to ns-resolution stat keys and atomic `dst` writes (4, 5).
4. Replace the manifest-repair claim with a write-then-rename manifest plus journal checkpointing (6).
5. Add a max-wait cap to the debounce (1).

Items 1–5 are design-level and cheap to fix now; the rest can wait for a prototype measurement.
