## Read summary

- `GOAL.md`: add `--json` (single JSON object on stdout: `copied` list, `skipped` N, `src`, `dst`), `--dry-run` interplay (copied = would-be), human mode unchanged, unit tests in `test_synccli.py`. Constraints: stdlib-only, Python 3.10, `sync()` signature stable.
- `README.md`: CLI entry `python3 -m synccli --help`, tests `python3 -m unittest -v`.
- Current code: `synccli.py` (`main()` prints one path per line; `sync()` returns the copied list and writes the manifest), `incremental.py` (imports `copy_file`), `test_synccli.py`.
- `DESIGN.md` describes a separate v2 daemon (`syncd`) — **out of scope** for this GOAL; do not implement it, do not delete it.

## Open gap to resolve before coding

`skipped` is not currently observable: `sync()` returns only the copied list, and the constraint forbids changing its signature. `skipped` must mean "source files already up to date (not copied)". The plan therefore routes this through a new internal helper (`sync_details()` / `collect_skipped()`) that `sync()` delegates to, keeping `sync(src_root, dst_root, dry_run=False)` byte-compatible.

---

## Execution plan (ordered)

### T1 — Baseline & semantics exploration
- **Objective:** confirm all internal callers of `sync()`/`copy_file` (repo + git history), confirm the test command works, and establish the exact definition of `skipped` and how to obtain it without changing `sync()`'s signature.
- **Files:** none modified (read-only): `synccli.py`, `incremental.py`, `test_synccli.py`, `git log -p -- synccli.py`.
- **Agent:** `explore` (read-only).
- **Risks:** hidden callers outside the repo (module named `synccli` may be imported elsewhere); `skipped` semantics ambiguity (source-only files vs. files skipped due to copy errors — `copy_file` swallows `OSError` at synccli.py:66-69).
- **Acceptance:** a written answer listing every `sync()` call site with file:line, the current test result (`python3 -m unittest -v` green), and one recommended `skipped` definition with its computation site.

### T2 — Design of the JSON contract
- **Objective:** design the output contract before code: exact JSON object shape (`copied` = list of relative paths, `skipped` = int, `src` = str, `dst` = str), stdout purity in `--json` mode (argparse errors/help go to stdout today — must go to stderr or be handled), dry-run semantics (`copied` = what would be copied; `skipped` identical to real run), and human mode byte-for-byte unchanged. Decide where JSON is emitted (in `main()`, never inside `sync()`).
- **Files:** design note (chat or `DESIGN-json.md` — only if user asks for a file).
- **Agent:** `cheap-design` (draft) → `cheap-design-review` (critique).
- **Risks:** argparse printing usage to stdout on error would violate "nothing else on stdout"; `json.dump` vs `print(json.dumps(...))` newline/ordering choices; Windows/`os.sep` path separators in `copied` entries vs. the `os.path.join("sub","b.txt")` convention already used in tests.
- **Acceptance:** a written spec both reviewers accept, stating the literal JSON output for a sample run and the stdout-purity rule for `--json` + `--help`/argparse errors.

### T3 — Implementation: CLI flags and output modes
- **Objective:** implement `--json` and the dry-run interplay in `synccli.py` without changing `sync()`'s signature; add the internal helper that exposes the skipped count; keep human mode unchanged.
- **Files:** `synccli.py` (modify: `main()`, add `--json` flag, add helper e.g. `sync_details(src_root, dst_root, dry_run=False)` returning `{copied, skipped}`, `sync()` refactored to delegate while keeping its exact signature and return value).
- **Agent:** `cheap-code` (implementation).
- **Risks:** accidental change to `sync()`'s signature/return; manifest write behavior in dry-run (must still not write the manifest — dry-run currently returns before writing, preserve that); `skipped` computed as "source files not copied" must not double-count; no new imports beyond stdlib (`json` already imported).
- **Acceptance:** `python3 -m synccli SRC DST --json` prints exactly one line of valid JSON with the four keys; `python3 -m synccli SRC DST` still prints one relative path per line; `python3 -m synccli SRC DST --json --dry-run` reports the same `copied` list as the real run and leaves the destination unmodified (no `.sync_manifest.json`, no files copied); existing `python3 -m unittest -v` still green.

### T4 — Implementation: unit tests
- **Objective:** add tests to `test_synccli.py` for the JSON shape and dry-run semantics, following the existing unittest style.
- **Files:** `test_synccli.py` (modify: new `TestJsonOutput` class and/or `TestDryRunJson`; capture stdout via `contextlib.redirect_stdout`).
- **Agent:** `cheap-code` (implementation).
- **Risks:** stdout capture must not swallow stderr; tests must be hermetic (use `tempfile.mkdtemp` as existing tests do); asserting on exact key set vs. subset (goal says keys must be present — assert superset, plus a single-JSON-object parse via `json.loads` to prove nothing else is printed); existing `test_synccli.py` structure preserved.
- **Acceptance:** new tests fail against pre-T3 code and pass after; `python3 -m unittest -v` fully green; a test asserts `json.loads(stdout)` yields exactly the four expected keys present, and that stdout in `--json` mode contains no extra lines.

### T5 — Review
- **Objective:** review the combined diff (T3 + T4) for correctness against GOAL.md and the T2 spec, and against the constraints (stdlib-only, `sync()` signature stability, human mode unchanged).
- **Files:** review only: `synccli.py`, `test_synccli.py`.
- **Agent:** `cheap-review` (mandatory, fresh session, self-contained brief).
- **Risks:** a reviewer finding that `skipped` semantics drifted from spec; missed stdout leakage (e.g. `print` in helpers, warnings from `os`); `copy_file` error swallowing making `copied` overstate reality.
- **Acceptance:** verdict with findings classified minor/major; minor findings are fixed by resuming the T3/T4 `cheap-code` session; zero major findings open before sign-off.

### T6 — Final verification (conditional, only if the user asks)
- **Objective:** end-to-end manual check of the release behavior.
- **Files:** none.
- **Agent:** `strong-review` (final audit of the diff) — expensive tier, run only on explicit request.
- **Risks:** none beyond cost.
- **Acceptance:** clean `python3 -m unittest -v` run plus a manual sample-run transcript matching the T2 spec.

---

**Notes:** no files were modified. `DESIGN.md` (v2 daemon) is deliberately out of scope; `README.md` would need a one-line `--json` mention, but per repo policy I did not include a doc-edit task — say the word and I will add it as T7.
