## Execution plan

**Baseline:** `python3 -B -m unittest -v` currently fails one existing test: `TestCollectStale.test_first_item_stale_is_included`. That failure is unrelated to the requested CLI feature and should be tracked separately.

1. **Explore — establish the output contract**
   - **Objective:** Confirm current sync, manifest, error and CLI behavior; resolve what `skipped` counts.
   - **Files:** Read `synccli.py` and `test_synccli.py`; no modifications.
   - **Risk:** `sync()` returns only paths selected for copying, not a skipped count. Its copy helper also suppresses some errors, so “copied” currently means selected for copying, not necessarily successfully written.
   - **Acceptance:** Document a proposed contract: `skipped` is the number of source files unchanged against the loaded manifest; preserve current copy and exit behavior. Flag any ambiguity for the design review.

2. **Design-review — validate the implementation approach**
   - **Objective:** Review how to derive both counts from the same manifest snapshot while retaining `sync(src_root, dst_root, dry_run=False)` and its list return value.
   - **Files:** Read `synccli.py`; no modifications.
   - **Risks:** A second scan can produce inconsistent counts; changing `sync()` breaks internal callers. Error and help output must retain existing exit behavior.
   - **Acceptance:** Approve an approach using a shared internal sync/report helper, with the existing `sync()` interface preserved and JSON serialization confined to CLI output.

3. **Impl — add JSON output and tests**
   - **Objective:** Add `--json`; output one JSON object with `copied`, `skipped`, `src`, and `dst`. With `--dry-run`, report paths that would be copied without writing files or the manifest. Preserve human output and exit behavior.
   - **Files:** Modify `synccli.py` and `test_synccli.py`.
   - **Risks:** Extra stdout corrupts JSON; computing `skipped` after writing the manifest gives wrong results; dry-run could accidentally mutate the destination.
   - **Acceptance:** Tests parse the entire stdout as one JSON object, verify all keys and values for a copy and a no-op, and verify dry-run paths and absence of destination changes. A human-mode test confirms one path per line. Python 3.10 standard library only; `sync()` signature and list return remain stable.

4. **Review — independently inspect and verify**
   - **Objective:** Review the diff against the contract and run the new tests and existing suite.
   - **Files:** Review `synccli.py` and `test_synccli.py`; no modifications by the reviewer.
   - **Risks:** Regressions hidden by the pre-existing failing test, or tests that miss stdout contamination and dry-run writes.
   - **Acceptance:** All new and relevant sync tests pass; the full suite is run and any remaining failures are identified against the baseline. Review confirms no new dependencies, unchanged human behavior and unchanged `sync()` interface.
