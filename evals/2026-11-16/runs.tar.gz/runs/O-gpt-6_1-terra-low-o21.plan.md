## Execution plan

**Assumption:** `skipped` counts source files unchanged according to the existing manifest. `copied` retains the current `sync()` meaning: paths selected for copying, or that would be selected during a dry run.

1. **Establish the baseline**
   - **Agent:** explore
   - **Objective:** Confirm current CLI behavior, `sync()` callers, test results, and how copy failures are reported.
   - **Files:** Read `synccli.py`, `incremental.py`, and `test_synccli.py`; modify none.
   - **Risks:** An existing failure could be mistaken for a regression. In particular, `collect_stale()` appears to omit its first item.
   - **Acceptance:** Run `python3 -m unittest -v` and record the exact baseline failures and observable CLI behavior.

2. **Review the output contract**
   - **Agent:** design-review
   - **Objective:** Validate the `skipped` assumption and a way to calculate it from the same source snapshot as `copied`, while preserving the `sync()` signature and return value.
   - **Files:** Read `GOAL.md` and `synccli.py`; modify none.
   - **Risks:** A second scan can produce inconsistent counts; `copy_file()` currently suppresses `OSError`, so selected paths are not necessarily confirmed successful copies.
   - **Acceptance:** Document an implementation approach covering normal and dry-run counts, compatibility, and existing error behavior. Resolve any contract ambiguity before implementation.

3. **Implement and test JSON mode**
   - **Agent:** impl
   - **Objective:** Add `--json` and emit exactly one JSON object with `copied`, `skipped`, `src`, and `dst`; retain human output, exit behavior, and the `sync()` interface.
   - **Files:** Modify `synccli.py` and `test_synccli.py`.
   - **Risks:** Extra stdout corrupts JSON; dry-run could write files or the manifest; refactoring could change internal callers’ results.
   - **Acceptance:** Tests parse the entire stdout as one object, check all keys and values for a first sync, unchanged files, and `--json --dry-run`, and verify dry-run leaves the destination and manifest untouched. Tests also cover human output and stable `sync()` behavior. Python 3.10 and stdlib only.

4. **Update usage documentation**
   - **Agent:** impl
   - **Objective:** Explain `--json`, its fields, and its interaction with `--dry-run`.
   - **Files:** Modify `README.md`.
   - **Risks:** Documentation could imply successful copies where current behavior reports selected paths.
   - **Acceptance:** The documented examples and field descriptions match the implemented CLI and `--help`.

5. **Review and verify**
   - **Agent:** review
   - **Objective:** Review the complete diff against the goal and run the test suite.
   - **Files:** Inspect `synccli.py`, `test_synccli.py`, and `README.md`; modify none.
   - **Risks:** Regressions may be obscured by baseline failures or by testing only JSON output.
   - **Acceptance:** `python3 -m unittest -v` has no new failures relative to the recorded baseline; all new tests pass. Report any pre-existing failures separately and return actionable findings to the implementer.

No files were modified, and the baseline tests were not run during this planning response.
