### Execution Plan: JSON Output Mode + Dry-Run UX

---

#### Task 1: Baseline Codebase & Test Audit
* **Objective:** Inspect existing call sites of `sync()`, verify the exact semantics of `skipped` (unchanged files in `src` vs. unreadable/excluded files), and confirm the current status of the existing `unittest` suite (noting any pre-existing test failures such as `collect_stale` so they don't confound verification).
* **Files to create/modify:** None (read-only).
* **Pipeline agent:** `explore`
* **Risks:**
  * Ambiguity around `skipped` count: `sync(src_root, dst_root, dry_run=False)` currently returns only `to_copy` (a `list[str]`), whereas `skipped` requires knowing total scanned source files minus `len(copied)` (or failed copies).
  * Pre-existing failing tests in `test_synccli.py` (e.g., `TestCollectStale` off-by-one in `synccli.py`) could mask or block test verification if not accounted for upfront.
* **Verifiable acceptance criterion:** Produces a concise brief documenting: (1) all callers of `sync()`, (2) exact baseline output of `python3 -m unittest -v`, and (3) how `skipped` is derived without breaking `sync(src_root, dst_root, dry_run=False) -> list[str]`.

---

#### Task 2: Design Review of `sync()` Stability & JSON Contract
* **Objective:** Validate the design for obtaining `skipped` count while keeping `sync(src_root, dst_root, dry_run=False)` signature and return type (`list[str]`) 100% backwards-compatible (e.g., introducing an internal helper `_sync_with_stats()` or computing `len(scan_files(src)) - len(copied)` / sharing manifest scan), and verify edge-case semantics (`src`/`dst` string formatting, empty directories, `--dry-run` + `--json`, stdout purity).
* **Files to create/modify:** None (read-only critique of proposed approach).
* **Pipeline agent:** `design-review` (`cheap-design-review`)
* **Risks:**
  * Double-scanning `src_root` (TOCTOU race if files change between `sync()` and counting `skipped`, plus redundant I/O) if `skipped` is computed naively outside `sync()`.
  * Altering `sync()`'s return value (e.g., returning a tuple or dict) would break internal callers (`test_synccli.py`, planned `syncd`) and violate `GOAL.md` constraints.
  * Hidden files or `.sync_manifest.json` inside `src_root` skewing `skipped` if `scan_files` vs `build_manifest` logic diverges.
* **Verifiable acceptance criterion:** Design sign-off confirming a single-scan internal helper (which `sync()` delegates to and unwraps `copied` from), exact JSON schema `{"copied": list[str], "skipped": int, "src": str, "dst": str}`, exit code `0`, and zero non-JSON bytes on `stdout` when `--json` is passed.

---

#### Task 3: Implement `--json` Flag and `--dry-run` Interplay in `synccli.py`
* **Objective:** Add `--json` (`action="store_true"`) to `argparse` in `main()`, extract/compute sync stats (`copied` list and `skipped` integer count = unchanged files in `src_manifest`) in a single pass while keeping `sync(src_root, dst_root, dry_run=False) -> list[str]` untouched, and emit either the single JSON object on `stdout` (`--json`) or one path per line (human mode).
* **Files to create/modify:** Modify `synccli.py`.
* **Pipeline agent:** `impl` (`cheap-code`)
* **Risks:**
  * Printing extra lines, warnings, or trailing debug output to `stdout` in `--json` mode (violating single JSON object requirement).
  * Mutating `dst` or writing `.sync_manifest.json` when both `--json` and `--dry-run` are passed.
  * Changing `src` or `dst` values in JSON output away from what the caller passed on the CLI (or inconsistent path normalization).
  * Introducing non-stdlib imports or Python >3.10 syntax.
* **Verifiable acceptance criterion:**
  * `python3 -m synccli <src> <dst> --json` outputs valid JSON matching `{"copied": [...], "skipped": N, "src": "<src>", "dst": "<dst>"}` and exits with `0`.
  * `python3 -m synccli <src> <dst> --dry-run --json` lists files that *would* be copied in `"copied"`, reports accurate `"skipped"`, leaves `<dst>` untouched, and exits with `0`.
  * `python3 -m synccli <src> <dst>` (without `--json`) still prints one relative path per line and nothing when `copied` is empty.
  * `inspect.signature(synccli.sync)` remains `(src_root, dst_root, dry_run=False)` returning `list[str]`.

---

#### Task 4: Add Unit Tests for JSON Mode, Human Mode, and Dry-Run Interplay
* **Objective:** Add comprehensive `unittest` test cases covering `--json` output validity, required keys and value types, `skipped` accuracy across initial and subsequent syncs, `--json --dry-run` non-mutation + `copied` preview semantics, human-mode regression check, and `main()` exit codes.
* **Files to create/modify:** Modify `test_synccli.py`.
* **Pipeline agent:** `impl` (`cheap-code`)
* **Risks:**
  * Capturing `stdout` improperly (leaking output between tests or not testing `main(argv)` directly).
  * Leaving temporary directories uncleaned or coupling tests to OS-specific path separators without `os.path.join`.
  * Touching unrelated tests or modifying unrelated bugs outside `GOAL.md` scope without user authorization.
* **Verifiable acceptance criterion:** Running `python3 -m unittest -v test_synccli.TestJsonOutput` (and all `TestSync` / new CLI tests) passes 100%, verifying `json.loads(stdout)` succeeds, `set(data.keys()) == {"copied", "skipped", "src", "dst"}`, `isinstance(data["skipped"], int)`, dry-run writes neither files nor `.sync_manifest.json`, and exit code is `0`.

---

#### Task 5: Mandatory Code & Test Review
* **Objective:** Perform an independent read-only review of the complete diff across `synccli.py` and `test_synccli.py` against `GOAL.md` constraints and Python 3.10 stdlib standards; classify any findings as minor (route back to `impl`) or major (escalate).
* **Files to create/modify:** None (read-only; triggers a targeted `impl` fix round only if findings exist).
* **Pipeline agent:** `review` (`cheap-review`)
* **Risks:**
  * Subtle edge cases missed in implementation: e.g., empty `src` directory (`copied: []`, `skipped: 0`), second run where all files are skipped (`copied: []`, `skipped: N`), nested subdirectories, non-ASCII filenames (`ensure_ascii` behavior), or `sync()` signature/return-type drift.
  * Unintended edits outside `synccli.py` and `test_synccli.py`.
* **Verifiable acceptance criterion:** Reviewer issues zero unresolved major/minor findings, `git diff --name-only` shows only `synccli.py` and `test_synccli.py`, all new and existing `sync` unit tests pass under `python3 -m unittest -v`, and zero third-party dependencies are imported.
