Here is a critique of `DESIGN.md` before implementation:

### 1. Wrong Assumptions & Contradictions

* **1-second `mtime` resolution causes silent data loss:** `snapshot()` stores `mtime` at whole-second granularity. Any edit that happens in the same second as the previous synced state without changing file size (e.g., `sed -i`, compiler/test-runner rewrites, `mmap` edits) produces an identical `(size, int(mtime))` and is **permanently missed**. Using `st_mtime_ns` + `st_ino`/`st_ctime_ns` reduces this, though tools that preserve `mtime` (`cp -p`, `tar`, `git`) still bypass `size + mtime`.
* **200 ms debounce vs. 500 ms poll is mathematically broken:** Polling every 500 ms cannot observe a 200 ms quiet period—changes between polls are invisible, and waiting for a clean poll adds up to 1000 ms, not 200 ms. Worse, *"every further observed change restarts the quiet period"* contradicts *"even while a file is being written continuously"*: a continuously written file (e.g., a log or slow artifact) will **starve indefinitely** and never sync.
* **In-place manifest rewrite corrupts crash recovery:** Writing the manifest in place (`open(..., 'w')`) truncates it first. A crash mid-write leaves a 0-byte or half-written/unparseable manifest. Replaying a delta journal onto a corrupt or empty manifest cannot repair it—it either crashes on startup or loses the 50,000-file state. (The design also never specifies when the journal is truncated, nor does it journal deletions.)
* **Lock scope contradicts single-instance safety:** Taking a PID lock per poll cycle and releasing it *before* the manifest commit creates a split-brain window: a second `syncd` can start, read the stale manifest, and copy files while the first is overwriting the manifest. PID files without `flock`/`fcntl` are also racy on check-then-create and stale after crashes.
* **Non-atomic writes to `dst`:** Writing directly to `dst/<file>` exposes partial/truncated files to readers during the copy and leaves corrupt files in `dst` if `syncd` crashes mid-copy. Re-statting `src` afterward only detects the race; it does not prevent `dst` from holding truncated data.

### 2. What Will Break Under Real Load

* **500 ms `os.walk` of 50,000 files will saturate CPU/IOPS:** "< 100 ms" only holds on a warm page cache on an idle local SSD. On cold caches, macOS APFS, VM/Docker bind mounts, or during an active build, 50,000 `stat`s can take 500 ms–several seconds. Without adaptive backoff or overlap guards, `syncd` spins at 100% I/O continuously.
* **Unbounded synchronous drain during build bursts:** Draining all pending files in a single poll pass blocks the daemon for the entire duration of a 1,000-file copy burst, stalling latency for small edits and queuing another huge batch behind it.
* **Missing filesystem edge cases:** No handling is specified for symlinks (loops or dangling targets), empty directories, permissions, or case-insensitive filesystems (macOS APFS, where renaming `Foo` → `foo` as delete+create can delete the newly created file).

### 3. Decisions to Change First

1. **Make manifest commits atomic (`tmp` + `fsync` + `os.replace`)** instead of in-place rewrites; drop the journal unless you also need mid-batch resume, or checkpoint the journal atomically with the manifest.
2. **Use `flock` held for the entire daemon lifetime** (not per-cycle, and never released before manifest commit).
3. **Store nanosecond `mtime_ns` + `size` (and ideally `ino`)** instead of whole-second `mtime` in `syncd`'s state.
4. **Write to `dst` atomically** via a staging temp file in `dst` + `os.replace()`.
5. **Fix the debounce/poll model:** Either use OS watchers (`FSEvents`/`inotify`) with periodic full-scan reconciliation, or bound the max-wait age on debounced files so continuously written files don't starve, and cap per-cycle copy work (or use a bounded worker queue).
