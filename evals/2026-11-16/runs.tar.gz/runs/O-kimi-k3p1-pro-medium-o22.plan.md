## Execution plan

### 1. Map the current CLI and synchronization flow
- **Objective:** Identify the CLI entry point, argument parsing, `sync()` signature and return value, dry-run behavior, stdout/stderr usage, exit-code handling, and existing test conventions. Confirm all internal `sync()` callers before choosing an implementation.
- **Files to create/modify:** None. Inspect `synccli` package files and `test_synccli.py`.
- **Pipeline agent:** **explore**
- **Risks:** Planning against assumed module names; overlooking non-CLI callers of `sync()`; confusing dry-run reporting with actual copy results; missing output emitted outside the main entry point.
- **Verifiable acceptance criterion:** A concise report with exact file/line references covering the output path, dry-run path, `sync()` signature and callers, exit-code propagation, and the existing test pattern.

### 2. Validate the minimal output-routing design
- **Objective:** Review a minimal design that adds `--json`, preserves `sync()` unchanged, collects the same source/destination/copy information for human and JSON modes, and routes human output versus exactly one JSON object through the CLI layer. Validate dry-run semantics and unchanged exit-code behavior without introducing dependencies.
- **Files to create/modify:** None. Review the relevant package files and `GOAL.md`.
- **Pipeline agent:** **design-review**
- **Risks:** Unnecessarily changing `sync()`; serializing before output is complete; allowing status messages on stdout; ambiguous `copied`/`skipped` values in dry-run mode; adding abstraction beyond this feature’s needs.
- **Verifiable acceptance criterion:** Approval of a design satisfying all `GOAL.md` constraints, or a documented blocking issue with a simpler corrective approach. The design must define the exact JSON object, list ordering consistent with existing output, stdout isolation, and dry-run behavior.

### 3. Implement JSON mode and its tests
- **Objective:** Add the `--json` flag; emit exactly one object with `copied`, `skipped`, `src`, and `dst`; make `--json --dry-run` report files that **would** be copied; preserve human-mode output and existing exit codes; add unit tests for JSON validity, required keys and types, normal operation, and dry-run semantics.
- **Files to create/modify:**
  - The CLI and synchronization module(s) identified in Task 1.
  - `test_synccli.py`.
  - No new dependencies or files unless the existing package structure strictly requires one.
- **Pipeline agent:** **impl** → **cheap-code**
- **Risks:** Printing JSON more than once; mixing logs or errors into stdout; changing human output; mutating the destination during dry-run; breaking internal callers by changing `sync()`; incomplete tests that check parseability but not behavior.
- **Verifiable acceptance criterion:**
  - `python3 -m unittest -v` passes.
  - `--json` stdout parses as one JSON object containing all four required keys, with `copied` as a list and `skipped` as an integer.
  - No other stdout content appears in JSON mode.
  - With `--json --dry-run`, `copied` identifies pending copies and the destination remains unchanged.
  - Existing human-output and exit-code tests still pass.
  - `sync()` retains its original signature and the implementation uses only the Python 3.10 standard library.

### 4. Perform independent regression and contract review
- **Objective:** Review the diff and test evidence against every requirement, looking specifically for signature drift, stdout contamination, dry-run side effects, altered exit behavior, and incomplete tests. Run the full suite and targeted CLI smoke checks.
- **Files to create/modify:** None during review; return any findings to the implementation agent for correction.
- **Pipeline agent:** **review** → **cheap-review**
- **Risks:** Tests sharing implementation assumptions; accidental behavior changes outside JSON mode; success based on happy-path tests only; JSON output validity depending on whether files were copied.
- **Verifiable acceptance criterion:** No unresolved findings; full tests pass; smoke checks cover JSON with copies, JSON with nothing to copy, and JSON plus dry-run; reviewer explicitly confirms stable `sync()` signature, unchanged human mode and exit codes, no new dependencies, and exact compliance with the required JSON shape.
