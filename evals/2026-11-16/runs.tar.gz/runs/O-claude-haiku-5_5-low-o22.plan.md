# Execution plan: `--json` output and dry-run UX for synccli

**Scope note:** I read GOAL.md and README.md only. I have not inspected the synccli source, so task 1 is a reconnaissance step that confirms the assumptions below before any design or code work. No files were modified.

**Goal recap:** `--json` prints one JSON object `{"copied": [...], "skipped": N, "src": ..., "dst": ...}` to stdout and nothing else. With `--dry-run`, `copied` lists what would be copied. Human output stays one path per line. Exit codes are unchanged. `sync()` keeps its signature. Stdlib only, Python 3.10.

---

### T1. Reconnaissance of the current code
- **Objective:** Map the current behaviour: `sync()` signature and return value, where stdout is printed, how `--dry-run` is implemented, how the manifest is read and written, and how `test_synccli.py` is structured.
- **Files:** read-only (`synccli/*.py`, `test_synccli.py`, `.sync_manifest.json` handling).
- **Agent:** `explore`.
- **Risks:** `sync()` may already print from inside (for example, per-file prints), which would break the "stdout is only JSON" rule. Dry-run may still write the manifest.
- **Acceptance:** A report with file:line references for: the `sync()` definition and return value, every `print` or `sys.stdout` call, the dry-run code path, and the existing test layout. T2 cannot start until this is delivered.

### T2. Design the JSON contract and dry-run semantics
- **Objective:** Write a short design note that settles these points:
  - Where `skipped` is counted under `--dry-run`.
  - Whether `src`/`dst` are the raw CLI strings or resolved absolute paths.
  - The key order and types.
  - Output on error in `--json` mode. Recommended: errors go to stderr only, and stdout stays empty or holds a JSON error object. This needs a decision, because the spec does not cover it.
  - How `sync()` returns its results without a signature change. Recommended: an internal helper that `sync()` wraps, or a returned value that existing callers ignore.
- **Files:** a design note only. Creating a new file needs your explicit yes; otherwise the note goes in the chat.
- **Agent:** `cheap-design`, then `cheap-design-review` (real design choices are involved here).
- **Risks:** Ambiguity about `skipped` under dry-run. Breaking internal callers if `sync()` changes shape.
- **Acceptance:** The note answers every point above. The reviewer signs off that `sync()`'s signature and existing callers are unaffected.

### T3. Implement `--json` output
- **Objective:** Add the `--json` flag to the argparse layer. Collect `copied`, `skipped`, `src`, and `dst`. Print a single `json.dumps` object to stdout. Route everything else to stderr or suppress it in JSON mode.
- **Files (expected):** the CLI entry module (for example `synccli/__main__.py`) and the `sync()` module, only for the return-value change.
- **Agent:** `cheap-code`, then `cheap-review` (mandatory). Escalate to `strong-code` only on a major finding or after two demonstrated stalls.
- **Risks:** Any stray `print` in `sync()` or in logging leaks into stdout. Exit code must stay the same on both success and failure.
- **Acceptance:** `python3 -m synccli --json <src> <dst> | python3 -c "import json,sys; json.load(sys.stdin)"` succeeds. Stdout contains nothing other than that object. Exit code matches the pre-change value.

### T4. Implement dry-run interplay
- **Objective:** With `--json --dry-run`, `copied` lists the files that would be copied. Nothing is written to `dst` and the manifest is not modified.
- **Files (expected):** the same modules as T3.
- **Agent:** `cheap-code`, then `cheap-review`.
- **Risks:** Dry-run reports a different `copied` set than a real run. Manifest writes leak through a dry-run path.
- **Acceptance:** Before and after a `--json --dry-run` run, the `dst` tree and the manifest are byte-identical. The `copied` list equals the set a real run would copy.

### T5. Tests in `test_synccli.py`
- **Objective:** Add unit tests for:
  - Valid JSON, and the presence and types of all four keys.
  - Dry-run semantics: `copied` is non-empty and no files are written.
  - Stdout is JSON only, captured with `redirect_stdout` or a subprocess.
  - Human mode output is unchanged (one path per line).
- **Files:** `test_synccli.py`.
- **Agent:** `cheap-code`, then `cheap-review`.
- **Risks:** Tests that pass without exercising the real code path, for example by mocking `sync()` entirely. Temp-dir cleanup leaking between tests.
- **Acceptance:** `python3 -m unittest -v` passes. Each new test fails when the feature is reverted, which can be checked by stashing the implementation.

### T6. Independent review of the full diff
- **Objective:** Review T3 through T5 together against GOAL.md: JSON-only stdout, dry-run semantics, exit codes, and the stable `sync()` signature.
- **Files:** read-only.
- **Agent:** `cheap-review`, in a fresh session, since review sessions must stay small. Because Claude-family code may be involved, the global rule also calls for a final audit by `strong-review` or `strong-review-alternative`. That audit is a final check, so I would book it only if the cheap review leaves doubt.
- **Risks:** Review of a growing diff in a reused session. Hidden stdout writes that tests miss.
- **Acceptance:** Findings are classified as minor or major. Minor findings go back to `cheap-code` through its `task_id`. Major findings escalate to `strong-code`.

### T7. End-to-end verification
- **Objective:** Run the commands by hand and confirm the behaviour in GOAL.md.
- **Commands:**
  - `python3 -m unittest -v`
  - `python3 -m synccli --json <src> <dst>`
  - `python3 -m synccli --json --dry-run <src> <dst>`
  - `python3 -m synccli <src> <dst>` (human mode)
  - Check the exit code in each case.
  - Confirm the stdlib-only constraint by checking imports.
- **Agent:** `cheap-mech`, or run directly by the orchestrator. It is a read and run task only.
- **Risks:** Testing on a Python version other than 3.10. Check with `python3 --version`.
- **Acceptance:** All commands produce the expected output and exit codes. The report includes the Python version used.

### T8. README update (optional, needs your yes)
- **Objective:** Document `--json` and the `--dry-run` interplay in README.md.
- **Files:** README.md.
- **Agent:** `cheap-code`, then `cheap-review`.
- **Risks:** This is an adjacent change not in GOAL.md, so per the global "ask before acting" rule it is skipped unless you approve it.
- **Acceptance:** The README examples match the actual output from T7.

---

**Execution order:** T1 → T2 → (T2 review) → T3 → T4 → T5 → T6 → T7 → (T8 if approved).

**Open decisions for you:**
1. Error-path output in `--json` mode (T2).
2. Whether `src`/`dst` are raw or resolved paths (T2).
3. Whether to include T8 (README).
