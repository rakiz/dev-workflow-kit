## Execution plan

1. **Establish the baseline — `explore`**
   - **Objective:** Trace `sync()` and CLI behavior; run the existing test suite and record failures.
   - **Files:** Read `synccli.py`, `test_synccli.py`, `incremental.py`; no changes.
   - **Risks:** An existing failure could be mistaken for a regression.
   - **Acceptance:** Document current output, exit and dry-run behavior, callers of `sync()`, and baseline test results. Inspection suggests `test_first_item_stale_is_included` currently fails because `collect_stale()` starts at index 1; confirm by running the suite.

2. **Review the output contract — `design-review`**
   - **Objective:** Agree how to collect the skipped count without changing `sync()`’s signature or return value. Define `skipped` as unchanged source files, and `src`/`dst` as the supplied argument strings.
   - **Files:** Review `synccli.py` and `GOAL.md`; no changes.
   - **Risks:** A second scan can produce inconsistent counts; `copy_file()` currently suppresses copy errors, so returned paths are not necessarily successful copies. Existing exceptions also prevent a JSON result.
   - **Acceptance:** Record a small implementation approach that derives counts from the same manifest snapshot, preserves existing exit/error behavior, and explicitly accounts for current copy-error semantics. Resolve any incompatible interpretation of the JSON requirement before implementation.

3. **Implement and test — `impl`**
   - **Objective:** Add `--json`, producing one JSON object with `copied`, `skipped`, `src`, and `dst`; report planned paths in JSON dry runs while preserving human output and `sync()` compatibility.
   - **Files:** Modify `synccli.py`, `test_synccli.py`, and `README.md` for flag usage; create no files.
   - **Risks:** Extra stdout output, changed human behavior, incorrect skipped counts, or writes during dry-run.
   - **Acceptance:** Tests parse the entire stdout as one object and verify its keys and values for initial sync, unchanged files, and dry-run; dry-run leaves destination and manifest unchanged. Tests also cover unchanged human output and the existing `sync()` interface. Use only the Python 3.10 standard library.

4. **Review and verify — `review`**
   - **Objective:** Independently review the diff against the goal and run `python3 -m unittest -v`.
   - **Files:** Review the files changed in task 3; no changes.
   - **Risks:** Regression hidden by a pre-existing failure, or JSON output contaminated by another print.
   - **Acceptance:** Review reports no unresolved in-scope findings; new tests pass, and the full-suite result is reported against the baseline. Any pre-existing failure remains separately identified rather than silently fixed.
