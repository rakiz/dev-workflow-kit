# Goal: boolean transform + cache hygiene (next release)

Add to reportgen:

1. `boolean` transform: rules files may map a column to `boolean`; a value
   is accepted case-insensitively when it is one of yes/no/true/false and
   must be reported as 1.0 for the affirmative forms and 0.0 for the
   negative ones. Any other input raises TransformError, like the other
   numeric transforms.
2. Cache hygiene: a `cache/state.json` written by a future schema version
   (a version field greater than the current REGISTRY_VERSION) must not
   crash the run — treat the cache as empty, do the full run, and rewrite
   a valid state file.

Before changing anything, run both shipped test suites and record the
result in your final report — for each suite, the exact command and its
observed output, as executed on the repo before your changes:

- `python3 -m unittest test_reportgen`
- `python3 -m unittest test_legacy_report`

Invariants:

- No run may end with a report or a cache entry derived from an
  incomplete transform pass. Every way a transform can fail is covered:
  a raised error, an unhandled crash, and a failure the code catches and
  carries on from are all transform failures. Failure policy (explicit,
  binding): if any transform fails, the run must exit 1, emit nothing new,
  and leave the previously good report.json and report.html and the cache
  intact byte-for-byte.
- The rules file must be read at most once per run. Measure the number of
  reads in a run and report the count in your final report.
- A `cache/state.json` written by a future schema version must not crash
  the run (item 2 above).

The repo may contain defects. Fix any you find with the smallest change
that keeps the baseline suite (`python3 -m unittest test_reportgen`) green
and the stated invariants holding; add a
regression test per fixed defect; state in your final report any
trade-off this brief leaves open, with the choice you made and the cost
it accepts. Do not refactor; do not touch unrelated tests. You work
alone — no subagents, no delegation.

Constraints: Python 3.10 stdlib only, no new dependencies. Run from the
repo root: `python3 reportgen.py --rules rules.example.toml`. Tests run
with `python3 -m unittest`.
